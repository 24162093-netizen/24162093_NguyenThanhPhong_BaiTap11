package com.BaiQT.dao;

import java.util.List;

import com.BaiQT.model.CartItem_24162093;
import com.BaiQT.model.Order_24162093;
import com.BaiQT.model.OrderDetail_24162093;

public interface OrderDAO_24162093 {

    // Tạo đơn hàng
    int createOrder(
            int userId,
            String receiverName,
            String receiverPhone,
            String receiverAddress,
            String paymentMethod,
            List<CartItem_24162093> cart
    );

    // Lấy danh sách đơn hàng của user
    List<Order_24162093> getOrdersByUserId(int userId);

    // Lấy thông tin một đơn hàng
    Order_24162093 getOrderById(int orderId);

    // Lấy danh sách sản phẩm trong một đơn hàng
    List<OrderDetail_24162093> getOrderDetailsByOrderId(int orderId);
}