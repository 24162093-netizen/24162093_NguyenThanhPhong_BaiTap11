package com.BaiQT.controller;

import java.io.IOException;
import java.util.List;

import com.BaiQT.dao.OrderDAO_24162093;
import com.BaiQT.dao.OrderDAOImpl_24162093;
import com.BaiQT.model.Order_24162093;
import com.BaiQT.model.User_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/orders")
public class OrderController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private OrderDAO_24162093 orderDAO;

    @Override
    public void init() throws ServletException {
        orderDAO = new OrderDAOImpl_24162093();
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        // Kiểm tra đăng nhập
        User_24162093 account =
                (User_24162093) session.getAttribute("account");

        if (account == null) {
            response.sendRedirect(
                    request.getContextPath() + "/login"
            );
            return;
        }

        // Lấy danh sách đơn hàng của user hiện tại
        List<Order_24162093> orders =
                orderDAO.getOrdersByUserId(account.getId());

        // Gửi danh sách đơn hàng sang JSP
        request.setAttribute("orders", orders);

        // Hiển thị trang danh sách đơn hàng
        request.getRequestDispatcher(
                "/WEB-INF/views/orders.jsp"
        ).forward(request, response);
    }
}