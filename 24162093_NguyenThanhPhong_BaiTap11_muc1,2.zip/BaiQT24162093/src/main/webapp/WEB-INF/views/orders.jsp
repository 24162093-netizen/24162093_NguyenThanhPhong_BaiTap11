<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<div class="orders-page">

    <div class="orders-header">

        <div class="orders-title">
            <h2>📦 Đơn hàng của tôi</h2>
            <p>Danh sách các đơn hàng bạn đã đặt</p>
        </div>

        <a
            href="${pageContext.request.contextPath}/home"
            class="back-btn">
            ← Quay lại trang chủ
        </a>

    </div>


    <c:choose>

        <%-- Có đơn hàng --%>

        <c:when test="${not empty orders}">

            <div class="orders-table-wrapper">

                <table class="orders-table">

                    <thead>

                        <tr>

                            <th>Mã đơn</th>
                            <th>Ngày đặt</th>
                            <th>Người nhận</th>
                            <th>Tổng tiền</th>
                            <th>Thanh toán</th>
                            <th>Trạng thái</th>
                            <th>Thao tác</th>

                        </tr>

                    </thead>


                    <tbody>

                        <c:forEach var="order" items="${orders}">

                            <tr>

                                <td>
                                    <strong>
                                        #${order.orderId}
                                    </strong>
                                </td>


                                <td>
                                    ${order.createdAt}
                                </td>


                                <td>
                                    ${order.receiverName}
                                </td>


                                <td class="order-total">
                                    ${order.totalAmount} ₫
                                </td>


                                <td>

                                    <c:choose>

                                        <c:when test="${order.paymentMethod == 'COD'}">
                                            COD
                                        </c:when>

                                        <c:otherwise>
                                            ${order.paymentMethod}
                                        </c:otherwise>

                                    </c:choose>

                                </td>


                                <td>

                                    <c:choose>

                                        <c:when test="${order.orderStatus == 'PENDING'}">

                                            <span class="status pending">
                                                Chờ xác nhận
                                            </span>

                                        </c:when>


                                        <c:when test="${order.orderStatus == 'CONFIRMED'}">

                                            <span class="status confirmed">
                                                Đã xác nhận
                                            </span>

                                        </c:when>


                                        <c:when test="${order.orderStatus == 'PREPARING'}">

                                            <span class="status preparing">
                                                Đang chuẩn bị
                                            </span>

                                        </c:when>


                                        <c:when test="${order.orderStatus == 'SHIPPING'}">

                                            <span class="status shipping">
                                                Đang giao hàng
                                            </span>

                                        </c:when>


                                        <c:when test="${order.orderStatus == 'DELIVERING'}">

                                            <span class="status delivering">
                                                Đang giao
                                            </span>

                                        </c:when>


                                        <c:when test="${order.orderStatus == 'DELIVERED'}">

                                            <span class="status delivered">
                                                Đã giao
                                            </span>

                                        </c:when>


                                        <c:when test="${order.orderStatus == 'CANCELLED'}">

                                            <span class="status cancelled">
                                                Đã hủy
                                            </span>

                                        </c:when>


                                        <c:when test="${order.orderStatus == 'RETURNED'}">

                                            <span class="status returned">
                                                Đã trả hàng
                                            </span>

                                        </c:when>


                                        <c:otherwise>

                                            <span class="status">
                                                ${order.orderStatus}
                                            </span>

                                        </c:otherwise>

                                    </c:choose>

                                </td>


                                <td>

                                    <a
                                        href="${pageContext.request.contextPath}/order-detail?orderId=${order.orderId}"
                                        class="btn-detail">
                                        Xem chi tiết
                                    </a>

                                </td>

                            </tr>

                        </c:forEach>

                    </tbody>

                </table>

            </div>

        </c:when>


        <%-- Chưa có đơn hàng --%>

        <c:otherwise>

            <div class="empty-orders">

                <div class="empty-icon">
                    📦
                </div>

                <h3>Chưa có đơn hàng</h3>

                <p>
                    Bạn chưa đặt đơn hàng nào.
                </p>

                <a
                    href="${pageContext.request.contextPath}/home"
                    class="btn-shopping">
                    🛒 Tiếp tục mua sắm
                </a>

            </div>

        </c:otherwise>

    </c:choose>

</div>


<style>

.orders-page {
    max-width: 1200px;
    margin: 30px auto;
    padding: 0 20px;
}


/* ============================= */
/* HEADER */
/* ============================= */

.orders-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 25px;
}

.orders-title h2 {
    margin: 0 0 8px;
    font-size: 28px;
}

.orders-title p {
    margin: 0;
    color: #666;
}


/* ============================= */
/* NÚT QUAY LẠI */
/* ============================= */

.back-btn {
    display: inline-block;
    padding: 10px 16px;
    border: 1px solid #ddd;
    border-radius: 6px;
    color: #333;
    background: #fff;
    text-decoration: none;
    white-space: nowrap;
}

.back-btn:hover {
    background: #f5f5f5;
}


/* ============================= */
/* TABLE */
/* ============================= */

.orders-table-wrapper {
    width: 100%;
    overflow-x: auto;
    background: #fff;
    border-radius: 10px;
}

.orders-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 900px;
}

.orders-table th {
    padding: 15px 12px;
    text-align: left;
    background: #f5f5f5;
    border-bottom: 1px solid #ddd;
    white-space: nowrap;
}

.orders-table td {
    padding: 15px 12px;
    border-bottom: 1px solid #eee;
    vertical-align: middle;
}

.orders-table tbody tr:hover {
    background: #fafafa;
}

.order-total {
    font-weight: bold;
}


/* ============================= */
/* STATUS */
/* ============================= */

.status {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 13px;
    white-space: nowrap;
}

.status.pending {
    background: #fff3cd;
    color: #856404;
}

.status.confirmed {
    background: #d1ecf1;
    color: #0c5460;
}

.status.preparing {
    background: #e2e3e5;
    color: #383d41;
}

.status.shipping,
.status.delivering {
    background: #cce5ff;
    color: #004085;
}

.status.delivered {
    background: #d4edda;
    color: #155724;
}

.status.cancelled {
    background: #f8d7da;
    color: #721c24;
}

.status.returned {
    background: #e2e3e5;
    color: #383d41;
}


/* ============================= */
/* NÚT CHI TIẾT */
/* ============================= */

.btn-detail {
    display: inline-block;
    padding: 8px 12px;
    background: #333;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-size: 13px;
    white-space: nowrap;
}

.btn-detail:hover {
    opacity: 0.85;
}


/* ============================= */
/* CHƯA CÓ ĐƠN */
/* ============================= */

.empty-orders {
    text-align: center;
    padding: 60px 20px;
    background: #fff;
    border-radius: 10px;
}

.empty-icon {
    font-size: 60px;
    margin-bottom: 15px;
}

.empty-orders h3 {
    margin-bottom: 8px;
}

.empty-orders p {
    color: #666;
    margin-bottom: 25px;
}


/* ============================= */
/* NÚT MUA SẮM */
/* ============================= */

.btn-shopping {
    display: inline-block;
    padding: 11px 18px;
    background: #333;
    color: white;
    text-decoration: none;
    border-radius: 6px;
}

.btn-shopping:hover {
    opacity: 0.85;
}


/* ============================= */
/* RESPONSIVE */
/* ============================= */

@media (max-width: 700px) {

    .orders-header {
        flex-direction: column;
        align-items: flex-start;
    }

    .back-btn {
        width: fit-content;
    }
}

</style>