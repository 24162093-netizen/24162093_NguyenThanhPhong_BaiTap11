package com.BaiQT.model;

import java.math.BigDecimal;

public class CartItem_24162093 {

    private Book_24162093 book;
    private int quantity;

    public CartItem_24162093() {
    }

    public CartItem_24162093(Book_24162093 book, int quantity) {
        this.book = book;
        this.quantity = quantity;
    }

    public Book_24162093 getBook() {
        return book;
    }

    public void setBook(Book_24162093 book) {
        this.book = book;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // =========================
    // TÍNH THÀNH TIỀN
    // =========================

    public BigDecimal getSubtotal() {

        if (book == null || book.getPrice() == null) {
            return BigDecimal.ZERO;
        }

        return book.getPrice()
                .multiply(BigDecimal.valueOf(quantity));
    }
}