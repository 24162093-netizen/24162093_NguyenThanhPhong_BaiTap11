package com.BaiQT.model;

public class BookAuthor_24162093 {

    private int bookid;
    private int authorId;

    public BookAuthor_24162093() {
    }

    public BookAuthor_24162093(int bookid, int authorId) {
        this.bookid = bookid;
        this.authorId = authorId;
    }

    public int getBookid() {
        return bookid;
    }

    public void setBookid(int bookid) {
        this.bookid = bookid;
    }

    public int getAuthorId() {
        return authorId;
    }

    public void setAuthorId(int authorId) {
        this.authorId = authorId;
    }
}