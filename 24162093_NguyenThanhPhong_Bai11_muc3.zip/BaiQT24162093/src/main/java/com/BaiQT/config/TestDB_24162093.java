package com.BaiQT.config;

import java.sql.Connection;

public class TestDB_24162093 {

    public static void main(String[] args) {

        try (Connection conn = DBConnection_24162093.getConnection()) {

            if (conn != null) {
                System.out.println("KET NOI DATABASE THANH CONG!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}