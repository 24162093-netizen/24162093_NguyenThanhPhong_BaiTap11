package com.BaiQT.dao;

import com.BaiQT.model.User_24162093;
import java.time.LocalDateTime;

public interface UserDAO_24162093 {

    User_24162093 findByEmail(String email);

    User_24162093 findById(int id);

    boolean insert(User_24162093 user);

    boolean update(User_24162093 user);

    void updateOTP(int userId, String otp, LocalDateTime expire);

    boolean verifyOTP(String email, String otp);
}