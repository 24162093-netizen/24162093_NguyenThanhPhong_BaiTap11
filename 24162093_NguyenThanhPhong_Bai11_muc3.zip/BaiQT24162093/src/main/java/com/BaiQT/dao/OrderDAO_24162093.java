package com.BaiQT.dao;

import java.util.List;

import com.BaiQT.model.CartItem_24162093;
import com.BaiQT.model.Order_24162093;
import com.BaiQT.model.OrderDetail_24162093;

public interface OrderDAO_24162093 {

    int createOrder(
            int userId,
            String receiverName,
            String receiverPhone,
            String receiverAddress,
            String paymentMethod,
            List<CartItem_24162093> cart
    );

    // Lấy toàn bộ đơn hàng của user
    List<Order_24162093> getOrdersByUserId(int userId);

    // Lấy đơn hàng của user theo trạng thái
    List<Order_24162093> getOrdersByUserIdAndStatus(
            int userId,
            String status
    );

    // Lấy một đơn hàng
    Order_24162093 getOrderById(int orderId);

    // Lấy chi tiết đơn hàng
    List<OrderDetail_24162093> getOrderDetailsByOrderId(int orderId);
}