package com.BaiQT.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import com.BaiQT.config.DBConnection_24162093;
import com.BaiQT.model.User_24162093;

public class UserDAOImpl_24162093 implements UserDAO_24162093 {

    @Override
    public User_24162093 findByEmail(String email) {

        String sql = "SELECT * FROM users WHERE email = ?";

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapUser(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public User_24162093 findById(int id) {

        String sql = "SELECT * FROM users WHERE id = ?";

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapUser(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public boolean insert(User_24162093 user) {

        String sql = """
                INSERT INTO users
                (email, fullname, phone, passwd, signup_date, is_admin, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getEmail());
            ps.setString(2, user.getFullname());
            ps.setInt(3, user.getPhone());
            ps.setString(4, user.getPasswd());

            if (user.getSignupDate() != null) {

                ps.setTimestamp(
                        5,
                        Timestamp.valueOf(user.getSignupDate())
                );

            } else {

                ps.setTimestamp(
                        5,
                        new Timestamp(System.currentTimeMillis())
                );
            }

            ps.setBoolean(6, user.isAdmin());

            // Tài khoản mới chưa xác nhận OTP
            ps.setBoolean(7, false);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean update(User_24162093 user) {

        String sql = """
                UPDATE users
                SET email = ?,
                    fullname = ?,
                    phone = ?,
                    passwd = ?,
                    last_login = ?,
                    is_admin = ?
                WHERE id = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getEmail());
            ps.setString(2, user.getFullname());
            ps.setInt(3, user.getPhone());
            ps.setString(4, user.getPasswd());

            if (user.getLastLogin() != null) {

                ps.setTimestamp(
                        5,
                        Timestamp.valueOf(user.getLastLogin())
                );

            } else {

                ps.setTimestamp(
                        5,
                        new Timestamp(System.currentTimeMillis())
                );
            }

            ps.setBoolean(6, user.isAdmin());
            ps.setInt(7, user.getId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public void updateOTP(
            int userId,
            String otp,
            LocalDateTime expire) {

        String sql = """
                UPDATE users
                SET otp_code = ?,
                    otp_expire = ?
                WHERE id = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, otp);

            ps.setTimestamp(
                    2,
                    Timestamp.valueOf(expire)
            );

            ps.setInt(3, userId);

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean verifyOTP(
            String email,
            String otp) {

        String sql = """
                UPDATE users
                SET is_active = 1,
                    otp_code = NULL,
                    otp_expire = NULL
                WHERE email = ?
                  AND otp_code = ?
                  AND otp_expire > NOW()
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, otp);

            int rows = ps.executeUpdate();

            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private User_24162093 mapUser(
            ResultSet rs) throws SQLException {

        User_24162093 user = new User_24162093();

        user.setId(rs.getInt("id"));

        user.setEmail(
                rs.getString("email")
        );

        user.setFullname(
                rs.getString("fullname")
        );

        user.setPhone(
                rs.getInt("phone")
        );

        user.setPasswd(
                rs.getString("passwd")
        );

        Timestamp signupDate =
                rs.getTimestamp("signup_date");

        if (signupDate != null) {

            user.setSignupDate(
                    signupDate.toLocalDateTime()
            );
        }

        Timestamp lastLogin =
                rs.getTimestamp("last_login");

        if (lastLogin != null) {

            user.setLastLogin(
                    lastLogin.toLocalDateTime()
            );
        }

        user.setAdmin(
                rs.getBoolean("is_admin")
        );

        // Lấy trạng thái xác thực OTP
        user.setActive(
                rs.getBoolean("is_active")
        );

        return user;
    }
}