package com.BaiQT.dao;

import java.util.List;

import com.BaiQT.model.Author_24162093;

public interface AuthorDAO_24162093 {

    List<Author_24162093> findAll();

    Author_24162093 findById(int authorId);

    boolean insert(Author_24162093 author);

    boolean update(Author_24162093 author);

    boolean delete(int authorId);
}