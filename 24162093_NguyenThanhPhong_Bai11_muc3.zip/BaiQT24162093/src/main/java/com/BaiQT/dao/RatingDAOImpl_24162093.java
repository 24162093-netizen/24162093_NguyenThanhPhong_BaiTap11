package com.BaiQT.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.BaiQT.config.DBConnection_24162093;
import com.BaiQT.model.Rating_24162093;

public class RatingDAOImpl_24162093 implements RatingDAO_24162093 {

    @Override
    public List<Rating_24162093> findByBookId(int bookid) {

        List<Rating_24162093> list = new ArrayList<>();

        String sql = """
                SELECT *
                FROM rating
                WHERE bookid = ?
                ORDER BY userid DESC
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bookid);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    list.add(mapRating(rs));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public List<Rating_24162093> findByBookId(int bookid, int limit) {

        List<Rating_24162093> list = new ArrayList<>();

        String sql = """
                SELECT *
                FROM rating
                WHERE bookid = ?
                ORDER BY userid DESC
                LIMIT ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bookid);
            ps.setInt(2, limit);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    list.add(mapRating(rs));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public Rating_24162093 findByUserAndBook(int userid, int bookid) {

        String sql = """
                SELECT *
                FROM rating
                WHERE userid = ?
                  AND bookid = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userid);
            ps.setInt(2, bookid);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapRating(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public boolean insert(Rating_24162093 rating) {

        String sql = """
                INSERT INTO rating
                (userid, bookid, rating, review_text)
                VALUES (?, ?, ?, ?)
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, rating.getUserid());
            ps.setInt(2, rating.getBookid());
            ps.setInt(3, rating.getRating());
            ps.setString(4, rating.getReviewText());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean update(Rating_24162093 rating) {

        String sql = """
                UPDATE rating
                SET rating = ?,
                    review_text = ?
                WHERE userid = ?
                  AND bookid = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, rating.getRating());
            ps.setString(2, rating.getReviewText());
            ps.setInt(3, rating.getUserid());
            ps.setInt(4, rating.getBookid());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean delete(int userid, int bookid) {

        String sql = """
                DELETE FROM rating
                WHERE userid = ?
                  AND bookid = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userid);
            ps.setInt(2, bookid);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private Rating_24162093 mapRating(ResultSet rs) throws SQLException {

        Rating_24162093 rating = new Rating_24162093();

        rating.setUserid(rs.getInt("userid"));
        rating.setBookid(rs.getInt("bookid"));
        rating.setRating(rs.getInt("rating"));
        rating.setReviewText(rs.getString("review_text"));

        return rating;
    }
}