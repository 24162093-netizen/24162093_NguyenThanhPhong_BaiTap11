package com.BaiQT.dao;

import java.util.List;

import com.BaiQT.model.BookAuthor_24162093;

public interface BookAuthorDAO_24162093 {

    List<BookAuthor_24162093> findByBookId(int bookid);

    List<BookAuthor_24162093> findByAuthorId(int authorId);

    boolean insert(BookAuthor_24162093 bookAuthor);

    boolean delete(int bookid, int authorId);

    boolean deleteByBookId(int bookid);
}