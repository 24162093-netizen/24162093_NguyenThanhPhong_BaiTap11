package com.BaiQT.dao;

import java.util.List;

import com.BaiQT.model.Rating_24162093;

public interface RatingDAO_24162093 {

    List<Rating_24162093> findByBookId(int bookid);

    List<Rating_24162093> findByBookId(int bookid, int limit);

    Rating_24162093 findByUserAndBook(int userid, int bookid);

    boolean insert(Rating_24162093 rating);

    boolean update(Rating_24162093 rating);

    boolean delete(int userid, int bookid);
}