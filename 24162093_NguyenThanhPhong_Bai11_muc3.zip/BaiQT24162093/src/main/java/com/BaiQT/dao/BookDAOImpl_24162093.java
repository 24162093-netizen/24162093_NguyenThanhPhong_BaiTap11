package com.BaiQT.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.BaiQT.config.DBConnection_24162093;
import com.BaiQT.model.Book_24162093;

public class BookDAOImpl_24162093 implements BookDAO_24162093 {

    @Override
    public List<Book_24162093> findAll() {

        List<Book_24162093> list = new ArrayList<>();

        String sql = """
                SELECT b.*,
                       (
                           SELECT GROUP_CONCAT(a.author_name SEPARATOR ', ')
                           FROM book_author ba
                           JOIN author a ON ba.author_id = a.author_id
                           WHERE ba.bookid = b.bookid
                       ) AS author_name
                FROM books b
                ORDER BY b.bookid DESC
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapBook(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public List<Book_24162093> findAll(int page, int pageSize) {

        List<Book_24162093> list = new ArrayList<>();

        String sql = """
                SELECT b.*,
                       (
                           SELECT GROUP_CONCAT(a.author_name SEPARATOR ', ')
                           FROM book_author ba
                           JOIN author a ON ba.author_id = a.author_id
                           WHERE ba.bookid = b.bookid
                       ) AS author_name
                FROM books b
                ORDER BY b.bookid DESC
                LIMIT ? OFFSET ?
                """;

        int offset = (page - 1) * pageSize;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, pageSize);
            ps.setInt(2, offset);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    list.add(mapBook(rs));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public Book_24162093 findById(int bookid) {

        String sql = """
                SELECT b.*,
                       (
                           SELECT GROUP_CONCAT(a.author_name SEPARATOR ', ')
                           FROM book_author ba
                           JOIN author a ON ba.author_id = a.author_id
                           WHERE ba.bookid = b.bookid
                       ) AS author_name
                FROM books b
                WHERE b.bookid = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bookid);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapBook(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public boolean insert(Book_24162093 book) {

        String sql = """
                INSERT INTO books
                (isbn, title, publisher, price, description,
                 publish_date, cover_image, quantity)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, book.getIsbn());
            ps.setString(2, book.getTitle());
            ps.setString(3, book.getPublisher());
            ps.setBigDecimal(4, book.getPrice());
            ps.setString(5, book.getDescription());

            if (book.getPublishDate() != null) {
                ps.setDate(6, Date.valueOf(book.getPublishDate()));
            } else {
                ps.setDate(6, null);
            }

            ps.setString(7, book.getCoverImage());
            ps.setInt(8, book.getQuantity());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean update(Book_24162093 book) {

        String sql = """
                UPDATE books
                SET isbn = ?,
                    title = ?,
                    publisher = ?,
                    price = ?,
                    description = ?,
                    publish_date = ?,
                    cover_image = ?,
                    quantity = ?
                WHERE bookid = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, book.getIsbn());
            ps.setString(2, book.getTitle());
            ps.setString(3, book.getPublisher());
            ps.setBigDecimal(4, book.getPrice());
            ps.setString(5, book.getDescription());

            if (book.getPublishDate() != null) {
                ps.setDate(6, Date.valueOf(book.getPublishDate()));
            } else {
                ps.setDate(6, null);
            }

            ps.setString(7, book.getCoverImage());
            ps.setInt(8, book.getQuantity());
            ps.setInt(9, book.getBookid());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean delete(int bookid) {

        String sql = "DELETE FROM books WHERE bookid = ?";

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bookid);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public int countBooks() {

        String sql = "SELECT COUNT(*) FROM books";

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    private Book_24162093 mapBook(ResultSet rs) throws SQLException {

        Book_24162093 book = new Book_24162093();

        book.setBookid(rs.getInt("bookid"));
        book.setIsbn(rs.getInt("isbn"));
        book.setTitle(rs.getString("title"));
        book.setPublisher(rs.getString("publisher"));
        book.setPrice(rs.getBigDecimal("price"));
        book.setDescription(rs.getString("description"));

        Date publishDate = rs.getDate("publish_date");

        if (publishDate != null) {
            book.setPublishDate(publishDate.toLocalDate());
        }

        book.setCoverImage(rs.getString("cover_image"));
        book.setQuantity(rs.getInt("quantity"));

        // Lấy tên tác giả
        book.setAuthorName(rs.getString("author_name"));

        return book;
    }
}