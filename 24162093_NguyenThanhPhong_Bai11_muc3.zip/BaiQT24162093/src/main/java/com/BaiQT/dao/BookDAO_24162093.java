package com.BaiQT.dao;

import java.util.List;

import com.BaiQT.model.Book_24162093;

public interface BookDAO_24162093 {

    List<Book_24162093> findAll();

    List<Book_24162093> findAll(int page, int pageSize);

    Book_24162093 findById(int bookid);

    boolean insert(Book_24162093 book);

    boolean update(Book_24162093 book);

    boolean delete(int bookid);

    int countBooks();
}