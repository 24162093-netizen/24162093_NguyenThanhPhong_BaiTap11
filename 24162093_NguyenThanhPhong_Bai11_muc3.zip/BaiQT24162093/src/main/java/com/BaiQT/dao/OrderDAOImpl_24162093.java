package com.BaiQT.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.BaiQT.config.DBConnection_24162093;
import com.BaiQT.model.CartItem_24162093;
import com.BaiQT.model.Order_24162093;
import com.BaiQT.model.OrderDetail_24162093;

public class OrderDAOImpl_24162093
        implements OrderDAO_24162093 {

    /*
     * =========================================================
     * TẠO ĐƠN HÀNG
     * =========================================================
     */

    @Override
    public int createOrder(
            int userId,
            String receiverName,
            String receiverPhone,
            String receiverAddress,
            String paymentMethod,
            List<CartItem_24162093> cart) {

        if (cart == null || cart.isEmpty()) {
            return -1;
        }

        Connection conn = null;

        try {
            conn = DBConnection_24162093.getConnection();

            /*
             * Bắt đầu transaction
             */
            conn.setAutoCommit(false);

            BigDecimal totalAmount = BigDecimal.ZERO;

            /*
             * =====================================================
             * 1. KIỂM TRA TỒN KHO VÀ TÍNH TỔNG TIỀN
             * =====================================================
             */

            String checkBookSql = """
                    SELECT title, price, quantity
                    FROM books
                    WHERE bookid = ?
                    FOR UPDATE
                    """;

            try (PreparedStatement checkBookPs =
                    conn.prepareStatement(checkBookSql)) {

                for (CartItem_24162093 item : cart) {

                    int bookid =
                            item.getBook().getBookid();

                    int requestedQuantity =
                            item.getQuantity();

                    checkBookPs.setInt(1, bookid);

                    try (ResultSet rs =
                            checkBookPs.executeQuery()) {

                        if (!rs.next()) {
                            conn.rollback();
                            return -1;
                        }

                        String title =
                                rs.getString("title");

                        BigDecimal price =
                                rs.getBigDecimal("price");

                        int stock =
                                rs.getInt("quantity");

                        /*
                         * Không đủ hàng
                         */
                        if (requestedQuantity <= 0
                                || requestedQuantity > stock) {

                            conn.rollback();
                            return -1;
                        }

                        BigDecimal subtotal =
                                price.multiply(
                                        BigDecimal.valueOf(
                                                requestedQuantity));

                        totalAmount =
                                totalAmount.add(subtotal);
                    }
                }
            }

            /*
             * =====================================================
             * 2. INSERT VÀO BẢNG ORDERS
             * =====================================================
             */

            String insertOrderSql = """
                    INSERT INTO orders
                    (
                        user_id,
                        receiver_name,
                        receiver_phone,
                        receiver_address,
                        total_amount,
                        payment_method,
                        order_status
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """;

            int orderId;

            try (PreparedStatement ps =
                    conn.prepareStatement(
                            insertOrderSql,
                            Statement.RETURN_GENERATED_KEYS)) {

                ps.setInt(1, userId);
                ps.setString(2, receiverName);
                ps.setString(3, receiverPhone);
                ps.setString(4, receiverAddress);
                ps.setBigDecimal(5, totalAmount);
                ps.setString(6, paymentMethod);

                /*
                 * Đơn hàng mới có trạng thái PENDING
                 */
                ps.setString(7, "PENDING");

                int affectedRows =
                        ps.executeUpdate();

                if (affectedRows == 0) {
                    conn.rollback();
                    return -1;
                }

                try (ResultSet rs =
                        ps.getGeneratedKeys()) {

                    if (!rs.next()) {
                        conn.rollback();
                        return -1;
                    }

                    orderId = rs.getInt(1);
                }
            }

            /*
             * =====================================================
             * 3. INSERT ORDER_DETAILS
             * =====================================================
             */

            String insertDetailSql = """
                    INSERT INTO order_details
                    (
                        order_id,
                        bookid,
                        book_title,
                        quantity,
                        unit_price,
                        subtotal
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                    """;

            String getBookSql = """
                    SELECT title, price
                    FROM books
                    WHERE bookid = ?
                    """;

            try (PreparedStatement detailPs =
                    conn.prepareStatement(insertDetailSql);
                 PreparedStatement bookPs =
                    conn.prepareStatement(getBookSql)) {

                for (CartItem_24162093 item : cart) {

                    int bookid =
                            item.getBook().getBookid();

                    int quantity =
                            item.getQuantity();

                    String title;
                    BigDecimal price;

                    bookPs.setInt(1, bookid);

                    try (ResultSet rs =
                            bookPs.executeQuery()) {

                        if (!rs.next()) {
                            conn.rollback();
                            return -1;
                        }

                        title =
                                rs.getString("title");

                        price =
                                rs.getBigDecimal("price");
                    }

                    BigDecimal subtotal =
                            price.multiply(
                                    BigDecimal.valueOf(
                                            quantity));

                    detailPs.setInt(1, orderId);
                    detailPs.setInt(2, bookid);
                    detailPs.setString(3, title);
                    detailPs.setInt(4, quantity);
                    detailPs.setBigDecimal(5, price);
                    detailPs.setBigDecimal(6, subtotal);

                    detailPs.addBatch();
                }

                detailPs.executeBatch();
            }

            /*
             * =====================================================
             * 4. TRỪ SỐ LƯỢNG SÁCH
             * =====================================================
             */

            String updateStockSql = """
                    UPDATE books
                    SET quantity = quantity - ?
                    WHERE bookid = ?
                    AND quantity >= ?
                    """;

            try (PreparedStatement stockPs =
                    conn.prepareStatement(updateStockSql)) {

                for (CartItem_24162093 item : cart) {

                    int quantity =
                            item.getQuantity();

                    int bookid =
                            item.getBook().getBookid();

                    stockPs.setInt(1, quantity);
                    stockPs.setInt(2, bookid);
                    stockPs.setInt(3, quantity);

                    int affected =
                            stockPs.executeUpdate();

                    /*
                     * Nếu không update được
                     * -> rollback toàn bộ đơn
                     */
                    if (affected == 0) {
                        conn.rollback();
                        return -1;
                    }
                }
            }

            /*
             * =====================================================
             * 5. COMMIT
             * =====================================================
             */

            conn.commit();

            return orderId;

        } catch (SQLException e) {

            e.printStackTrace();

            /*
             * Có lỗi -> rollback
             */
            if (conn != null) {

                try {
                    conn.rollback();

                } catch (SQLException rollbackException) {
                    rollbackException.printStackTrace();
                }
            }

            return -1;

        } finally {

            if (conn != null) {

                try {
                    conn.setAutoCommit(true);
                    conn.close();

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    /*
     * =========================================================
     * LẤY DANH SÁCH ĐƠN HÀNG CỦA USER
     * =========================================================
     */

    @Override
    public List<Order_24162093> getOrdersByUserId(int userId) {

        List<Order_24162093> orders =
                new ArrayList<>();

        String sql = """
                SELECT order_id,
                       user_id,
                       receiver_name,
                       receiver_phone,
                       receiver_address,
                       total_amount,
                       payment_method,
                       order_status,
                       created_at
                FROM orders
                WHERE user_id = ?
                ORDER BY created_at DESC
                """;

        try (Connection conn =
                    DBConnection_24162093.getConnection();
             PreparedStatement ps =
                    conn.prepareStatement(sql)) {

            ps.setInt(1, userId);

            try (ResultSet rs =
                    ps.executeQuery()) {

                while (rs.next()) {

                    Order_24162093 order =
                            new Order_24162093();

                    order.setOrderId(
                            rs.getInt("order_id"));

                    order.setUserId(
                            rs.getInt("user_id"));

                    order.setReceiverName(
                            rs.getString("receiver_name"));

                    order.setReceiverPhone(
                            rs.getString("receiver_phone"));

                    order.setReceiverAddress(
                            rs.getString("receiver_address"));

                    order.setTotalAmount(
                            rs.getBigDecimal("total_amount"));

                    order.setPaymentMethod(
                            rs.getString("payment_method"));

                    order.setOrderStatus(
                            rs.getString("order_status"));

                    order.setCreatedAt(
                            rs.getTimestamp("created_at")
                                    .toLocalDateTime());

                    orders.add(order);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return orders;
    }


    /*
     * =========================================================
     * LẤY DANH SÁCH ĐƠN HÀNG THEO TRẠNG THÁI
     * =========================================================
     */

    @Override
    public List<Order_24162093> getOrdersByUserIdAndStatus(
            int userId,
            String status) {

        List<Order_24162093> orders =
                new ArrayList<>();

        String sql = """
                SELECT order_id,
                       user_id,
                       receiver_name,
                       receiver_phone,
                       receiver_address,
                       total_amount,
                       payment_method,
                       order_status,
                       created_at
                FROM orders
                WHERE user_id = ?
                  AND order_status = ?
                ORDER BY created_at DESC
                """;

        try (Connection conn =
                    DBConnection_24162093.getConnection();
             PreparedStatement ps =
                    conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setString(2, status);

            try (ResultSet rs =
                    ps.executeQuery()) {

                while (rs.next()) {

                    Order_24162093 order =
                            new Order_24162093();

                    order.setOrderId(
                            rs.getInt("order_id"));

                    order.setUserId(
                            rs.getInt("user_id"));

                    order.setReceiverName(
                            rs.getString("receiver_name"));

                    order.setReceiverPhone(
                            rs.getString("receiver_phone"));

                    order.setReceiverAddress(
                            rs.getString("receiver_address"));

                    order.setTotalAmount(
                            rs.getBigDecimal("total_amount"));

                    order.setPaymentMethod(
                            rs.getString("payment_method"));

                    order.setOrderStatus(
                            rs.getString("order_status"));

                    if (rs.getTimestamp("created_at") != null) {
                        order.setCreatedAt(
                                rs.getTimestamp("created_at")
                                        .toLocalDateTime());
                    }

                    orders.add(order);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return orders;
    }


    /*
     * =========================================================
     * LẤY 1 ĐƠN HÀNG THEO ORDER ID
     * =========================================================
     */

    @Override
    public Order_24162093 getOrderById(int orderId) {

        String sql = """
                SELECT order_id,
                       user_id,
                       receiver_name,
                       receiver_phone,
                       receiver_address,
                       total_amount,
                       payment_method,
                       order_status,
                       created_at
                FROM orders
                WHERE order_id = ?
                """;

        try (Connection conn =
                    DBConnection_24162093.getConnection();
             PreparedStatement ps =
                    conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);

            try (ResultSet rs =
                    ps.executeQuery()) {

                if (rs.next()) {

                    Order_24162093 order =
                            new Order_24162093();

                    order.setOrderId(
                            rs.getInt("order_id"));

                    order.setUserId(
                            rs.getInt("user_id"));

                    order.setReceiverName(
                            rs.getString("receiver_name"));

                    order.setReceiverPhone(
                            rs.getString("receiver_phone"));

                    order.setReceiverAddress(
                            rs.getString("receiver_address"));

                    order.setTotalAmount(
                            rs.getBigDecimal("total_amount"));

                    order.setPaymentMethod(
                            rs.getString("payment_method"));

                    order.setOrderStatus(
                            rs.getString("order_status"));

                    if (rs.getTimestamp("created_at") != null) {
                        order.setCreatedAt(
                                rs.getTimestamp("created_at")
                                        .toLocalDateTime());
                    }

                    return order;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }


    /*
     * =========================================================
     * LẤY CHI TIẾT CỦA 1 ĐƠN HÀNG
     * =========================================================
     */

    @Override
    public List<OrderDetail_24162093> getOrderDetailsByOrderId(
            int orderId) {

        List<OrderDetail_24162093> details =
                new ArrayList<>();

        String sql = """
                SELECT order_detail_id,
                       order_id,
                       bookid,
                       book_title,
                       quantity,
                       unit_price,
                       subtotal
                FROM order_details
                WHERE order_id = ?
                ORDER BY order_detail_id
                """;

        try (Connection conn =
                    DBConnection_24162093.getConnection();
             PreparedStatement ps =
                    conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);

            try (ResultSet rs =
                    ps.executeQuery()) {

                while (rs.next()) {

                    OrderDetail_24162093 detail =
                            new OrderDetail_24162093();

                    detail.setOrderDetailId(
                            rs.getInt("order_detail_id"));

                    detail.setOrderId(
                            rs.getInt("order_id"));

                    detail.setBookid(
                            rs.getInt("bookid"));

                    detail.setBookTitle(
                            rs.getString("book_title"));

                    detail.setQuantity(
                            rs.getInt("quantity"));

                    detail.setUnitPrice(
                            rs.getBigDecimal("unit_price"));

                    detail.setSubtotal(
                            rs.getBigDecimal("subtotal"));

                    details.add(detail);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return details;
    }

}