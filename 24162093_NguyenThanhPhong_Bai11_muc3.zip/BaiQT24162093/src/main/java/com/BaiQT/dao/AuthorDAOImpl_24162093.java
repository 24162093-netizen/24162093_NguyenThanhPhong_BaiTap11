package com.BaiQT.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.BaiQT.config.DBConnection_24162093;
import com.BaiQT.model.Author_24162093;

public class AuthorDAOImpl_24162093 implements AuthorDAO_24162093 {

    @Override
    public List<Author_24162093> findAll() {

        List<Author_24162093> list = new ArrayList<>();

        String sql = "SELECT * FROM author ORDER BY author_id";

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapAuthor(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public Author_24162093 findById(int authorId) {

        String sql = "SELECT * FROM author WHERE author_id = ?";

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, authorId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapAuthor(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public boolean insert(Author_24162093 author) {

        String sql = """
                INSERT INTO author
                (author_name, date_of_birth)
                VALUES (?, ?)
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, author.getAuthorName());

            if (author.getDateOfBirth() != null) {
                ps.setDate(2, Date.valueOf(author.getDateOfBirth()));
            } else {
                ps.setDate(2, null);
            }

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean update(Author_24162093 author) {

        String sql = """
                UPDATE author
                SET author_name = ?,
                    date_of_birth = ?
                WHERE author_id = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, author.getAuthorName());

            if (author.getDateOfBirth() != null) {
                ps.setDate(2, Date.valueOf(author.getDateOfBirth()));
            } else {
                ps.setDate(2, null);
            }

            ps.setInt(3, author.getAuthorId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean delete(int authorId) {

        String sql = "DELETE FROM author WHERE author_id = ?";

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, authorId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private Author_24162093 mapAuthor(ResultSet rs) throws SQLException {

        Author_24162093 author = new Author_24162093();

        author.setAuthorId(rs.getInt("author_id"));
        author.setAuthorName(rs.getString("author_name"));

        Date dateOfBirth = rs.getDate("date_of_birth");

        if (dateOfBirth != null) {
            author.setDateOfBirth(dateOfBirth.toLocalDate());
        }

        return author;
    }
}