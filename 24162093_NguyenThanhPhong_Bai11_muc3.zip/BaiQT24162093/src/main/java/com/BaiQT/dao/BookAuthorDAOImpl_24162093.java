package com.BaiQT.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.BaiQT.config.DBConnection_24162093;
import com.BaiQT.model.BookAuthor_24162093;

public class BookAuthorDAOImpl_24162093 implements BookAuthorDAO_24162093 {

    @Override
    public List<BookAuthor_24162093> findByBookId(int bookid) {

        List<BookAuthor_24162093> list = new ArrayList<>();

        String sql = """
                SELECT *
                FROM book_author
                WHERE bookid = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bookid);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    list.add(mapBookAuthor(rs));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public List<BookAuthor_24162093> findByAuthorId(int authorId) {

        List<BookAuthor_24162093> list = new ArrayList<>();

        String sql = """
                SELECT *
                FROM book_author
                WHERE author_id = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, authorId);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    list.add(mapBookAuthor(rs));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public boolean insert(BookAuthor_24162093 bookAuthor) {

        String sql = """
                INSERT INTO book_author
                (bookid, author_id)
                VALUES (?, ?)
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bookAuthor.getBookid());
            ps.setInt(2, bookAuthor.getAuthorId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean delete(int bookid, int authorId) {

        String sql = """
                DELETE FROM book_author
                WHERE bookid = ?
                  AND author_id = ?
                """;

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bookid);
            ps.setInt(2, authorId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean deleteByBookId(int bookid) {

        String sql = "DELETE FROM book_author WHERE bookid = ?";

        try (Connection conn = DBConnection_24162093.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bookid);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private BookAuthor_24162093 mapBookAuthor(ResultSet rs)
            throws SQLException {

        BookAuthor_24162093 bookAuthor = new BookAuthor_24162093();

        bookAuthor.setBookid(rs.getInt("bookid"));
        bookAuthor.setAuthorId(rs.getInt("author_id"));

        return bookAuthor;
    }
}