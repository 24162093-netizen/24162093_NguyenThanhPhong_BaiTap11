package com.BaiQT.controller;

import java.io.IOException;
import java.util.List;

import com.BaiQT.model.Book_24162093;
import com.BaiQT.service.BookService_24162093;
import com.BaiQT.service.BookServiceImpl_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/admin/books")
public class AdminBookController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private BookService_24162093 bookService;

    @Override
    public void init() throws ServletException {
        bookService = new BookServiceImpl_24162093();
    }

    @Override
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("account") == null) {
            response.sendRedirect(
                request.getContextPath() + "/login"
            );
            return;
        }

        com.BaiQT.model.User_24162093 user =
                (com.BaiQT.model.User_24162093)
                session.getAttribute("account");

        if (!user.isAdmin()) {
            response.sendRedirect(
                request.getContextPath() + "/home"
            );
            return;
        }

        int page = 1;

        String pageParam = request.getParameter("page");

        if (pageParam != null) {
            try {
                page = Integer.parseInt(pageParam);

                if (page < 1) {
                    page = 1;
                }

            } catch (NumberFormatException e) {
                page = 1;
            }
        }

        int pageSize = 3;

        List<Book_24162093> books =
                bookService.getBooksByPage(page, pageSize);

        int totalPages =
                bookService.getTotalPages(pageSize);

        request.setAttribute("books", books);
        request.setAttribute("currentPage", page);
        request.setAttribute("totalPages", totalPages);

        request.getRequestDispatcher(
            "/WEB-INF/views/admin/books.jsp"
        ).forward(request, response);
    }
}