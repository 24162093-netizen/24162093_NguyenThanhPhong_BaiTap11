package com.BaiQT.controller;

import java.io.IOException;

import com.BaiQT.model.Rating_24162093;
import com.BaiQT.model.User_24162093;
import com.BaiQT.service.RatingService_24162093;
import com.BaiQT.service.RatingServiceImpl_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/review")
public class ReviewController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private RatingService_24162093 ratingService;

    @Override
    public void init() throws ServletException {
        ratingService = new RatingServiceImpl_24162093();
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("account") == null) {
            response.sendRedirect(
                request.getContextPath() + "/login"
            );
            return;
        }

        User_24162093 user =
                (User_24162093) session.getAttribute("account");

        String bookIdParam = request.getParameter("bookid");
        String ratingParam = request.getParameter("rating");
        String reviewText = request.getParameter("reviewText");

        int bookid;
        int rating;

        try {
            bookid = Integer.parseInt(bookIdParam);
            rating = Integer.parseInt(ratingParam);
        } catch (NumberFormatException e) {
            response.sendRedirect(
                request.getContextPath() + "/home"
            );
            return;
        }

        if (rating < 1 || rating > 5) {
            response.sendRedirect(
                request.getContextPath()
                + "/book-detail?id=" + bookid
            );
            return;
        }

        Rating_24162093 review = new Rating_24162093();

        review.setUserid(user.getId());
        review.setBookid(bookid);
        review.setRating(rating);
        review.setReviewText(reviewText);

        ratingService.addReview(review);

        response.sendRedirect(
            request.getContextPath()
            + "/book-detail?id=" + bookid
        );
    }
}