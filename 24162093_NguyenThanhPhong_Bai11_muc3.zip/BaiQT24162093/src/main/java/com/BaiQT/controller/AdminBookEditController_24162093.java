package com.BaiQT.controller;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

import com.BaiQT.model.Book_24162093;
import com.BaiQT.model.User_24162093;
import com.BaiQT.service.BookService_24162093;
import com.BaiQT.service.BookServiceImpl_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

@WebServlet("/admin/books/edit")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,
    maxFileSize = 5 * 1024 * 1024,
    maxRequestSize = 10 * 1024 * 1024
)
public class AdminBookEditController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private BookService_24162093 bookService;

    @Override
    public void init() throws ServletException {
        bookService = new BookServiceImpl_24162093();
    }

    // =========================
    // KIỂM TRA ADMIN
    // =========================

    private boolean checkAdmin(
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException {

        HttpSession session =
                request.getSession(false);

        if (session == null
                || session.getAttribute("account") == null) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/login"
            );

            return false;
        }

        User_24162093 user =
                (User_24162093) session.getAttribute("account");

        if (!user.isAdmin()) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/home"
            );

            return false;
        }

        return true;
    }

    // =========================
    // HIỂN THỊ FORM EDIT
    // =========================

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        if (!checkAdmin(request, response)) {
            return;
        }

        String idParam =
                request.getParameter("id");

        if (idParam == null
                || idParam.trim().isEmpty()) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/admin/books"
            );

            return;
        }

        try {

            int bookid =
                    Integer.parseInt(idParam);

            Book_24162093 book =
                    bookService.getBookById(bookid);

            if (book == null) {

                response.sendRedirect(
                        request.getContextPath()
                        + "/admin/books"
                );

                return;
            }

            request.setAttribute(
                    "book",
                    book
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/admin/book-form.jsp"
            ).forward(request, response);

        } catch (NumberFormatException e) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/admin/books"
            );
        }
    }

    // =========================
    // UPDATE + UPLOAD ẢNH
    // =========================

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        if (!checkAdmin(request, response)) {
            return;
        }

        request.setCharacterEncoding("UTF-8");

        String oldImage = null;
        String newImage = null;

        try {

            // =========================
            // BOOK ID
            // =========================

            int bookid =
                    Integer.parseInt(
                            request.getParameter("bookid")
                    );

            // =========================
            // LẤY SÁCH CŨ
            // =========================

            Book_24162093 oldBook =
                    bookService.getBookById(bookid);

            if (oldBook == null) {

                response.sendRedirect(
                        request.getContextPath()
                        + "/admin/books"
                );

                return;
            }

            oldImage =
                    oldBook.getCoverImage();

            // =========================
            // LẤY DỮ LIỆU FORM
            // =========================

            int isbn =
                    Integer.parseInt(
                            request.getParameter("isbn")
                    );

            String title =
                    request.getParameter("title");

            String publisher =
                    request.getParameter("publisher");

            BigDecimal price =
                    new BigDecimal(
                            request.getParameter("price")
                    );

            String description =
                    request.getParameter("description");

            String publishDateParam =
                    request.getParameter("publishDate");

            int quantity =
                    Integer.parseInt(
                            request.getParameter("quantity")
                    );

            LocalDate publishDate = null;

            if (publishDateParam != null
                    && !publishDateParam.trim().isEmpty()) {

                publishDate =
                        LocalDate.parse(
                                publishDateParam
                        );
            }

            // =========================
            // LẤY ẢNH MỚI
            // =========================

            Part imagePart =
                    request.getPart("coverImage");

            String coverImage =
                    oldImage;

            if (imagePart != null
                    && imagePart.getSize() > 0) {

                String originalName =
                        imagePart.getSubmittedFileName();

                String extension = "";

                if (originalName != null
                        && originalName.contains(".")) {

                    extension =
                            originalName.substring(
                                    originalName.lastIndexOf(".")
                            );
                }

                extension =
                        extension.toLowerCase();

                // Kiểm tra định dạng
                if (!extension.equals(".jpg")
                        && !extension.equals(".jpeg")
                        && !extension.equals(".png")
                        && !extension.equals(".gif")
                        && !extension.equals(".webp")) {

                    request.setAttribute(
                            "error",
                            "Chỉ được upload file ảnh JPG, JPEG, PNG, GIF hoặc WEBP!"
                    );

                    request.setAttribute(
                            "book",
                            oldBook
                    );

                    request.getRequestDispatcher(
                            "/WEB-INF/views/admin/book-form.jsp"
                    ).forward(request, response);

                    return;
                }

                // Tạo tên mới
                newImage =
                        UUID.randomUUID().toString()
                        + extension;

                String uploadPath =
                        getServletContext()
                                .getRealPath("/images");

                File uploadDir =
                        new File(uploadPath);

                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }

                String filePath =
                        uploadPath
                        + File.separator
                        + newImage;

                imagePart.write(filePath);

                coverImage =
                        newImage;
            }

            // =========================
            // TẠO BOOK UPDATE
            // =========================

            Book_24162093 book =
                    new Book_24162093();

            book.setBookid(bookid);
            book.setIsbn(isbn);
            book.setTitle(title);
            book.setPublisher(publisher);
            book.setPrice(price);
            book.setDescription(description);
            book.setPublishDate(publishDate);
            book.setCoverImage(coverImage);
            book.setQuantity(quantity);

            // =========================
            // UPDATE DATABASE
            // =========================

            boolean success =
                    bookService.updateBook(book);

            if (success) {

                // Nếu có ảnh mới
                // xóa ảnh cũ
                if (newImage != null
                        && oldImage != null
                        && !oldImage.isBlank()) {

                    String uploadPath =
                            getServletContext()
                                    .getRealPath("/images");

                    File oldFile =
                            new File(
                                    uploadPath,
                                    oldImage
                            );

                    if (oldFile.exists()) {
                        oldFile.delete();
                    }
                }

                response.sendRedirect(
                        request.getContextPath()
                        + "/admin/books"
                );

            } else {

                // DB update thất bại
                // Xóa ảnh mới vừa upload
                if (newImage != null) {

                    String uploadPath =
                            getServletContext()
                                    .getRealPath("/images");

                    File newFile =
                            new File(
                                    uploadPath,
                                    newImage
                            );

                    if (newFile.exists()) {
                        newFile.delete();
                    }
                }

                request.setAttribute(
                        "error",
                        "Cập nhật sách thất bại!"
                );

                request.setAttribute(
                        "book",
                        oldBook
                );

                request.getRequestDispatcher(
                        "/WEB-INF/views/admin/book-form.jsp"
                ).forward(request, response);
            }

        } catch (Exception e) {

            e.printStackTrace();

            // Nếu xảy ra lỗi thì xóa ảnh mới
            if (newImage != null) {

                String uploadPath =
                        getServletContext()
                                .getRealPath("/images");

                File newFile =
                        new File(
                                uploadPath,
                                newImage
                        );

                if (newFile.exists()) {
                    newFile.delete();
                }
            }

            request.setAttribute(
                    "error",
                    "Dữ liệu nhập vào không hợp lệ!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/admin/book-form.jsp"
            ).forward(request, response);
        }
    }
}