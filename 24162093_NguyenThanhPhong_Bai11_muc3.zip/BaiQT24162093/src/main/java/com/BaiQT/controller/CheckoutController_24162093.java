package com.BaiQT.controller;

import java.io.IOException;
import java.util.List;

import com.BaiQT.dao.OrderDAO_24162093;
import com.BaiQT.dao.OrderDAOImpl_24162093;
import com.BaiQT.model.CartItem_24162093;
import com.BaiQT.model.User_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/checkout")
public class CheckoutController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private OrderDAO_24162093 orderDAO;

    @Override
    public void init() {
        orderDAO = new OrderDAOImpl_24162093();
    }

    /*
     * =====================================================
     * HIỂN THỊ TRANG CHECKOUT
     * =====================================================
     */
    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
                request.getSession(false);

        /*
         * Chưa đăng nhập
         */
        if (session == null
                || session.getAttribute("account") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login");

            return;
        }

        /*
         * Kiểm tra giỏ hàng
         */
        Object cartObject =
                session.getAttribute("cart");

        if (!(cartObject instanceof List)
                || ((List<?>) cartObject).isEmpty()) {

            response.sendRedirect(
                    request.getContextPath() + "/cart");

            return;
        }

        /*
         * Mở checkout.jsp
         */
        request.getRequestDispatcher(
                "/WEB-INF/views/checkout.jsp")
                .forward(request, response);
    }

    /*
     * =====================================================
     * XỬ LÝ ĐẶT HÀNG COD
     * =====================================================
     */
    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session =
                request.getSession(false);

        /*
         * =================================================
         * 1. KIỂM TRA ĐĂNG NHẬP
         * =================================================
         */

        if (session == null
                || session.getAttribute("account") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login");

            return;
        }

        /*
         * =================================================
         * 2. LẤY USER
         * =================================================
         */

        User_24162093 user =
                (User_24162093)
                        session.getAttribute("account");

        if (user == null || user.getId() <= 0) {

            response.sendRedirect(
                    request.getContextPath() + "/login");

            return;
        }

        /*
         * =================================================
         * 3. LẤY THÔNG TIN FORM
         * =================================================
         */

        String receiverName =
                request.getParameter("receiverName");

        String receiverPhone =
                request.getParameter("receiverPhone");

        String receiverAddress =
                request.getParameter("receiverAddress");

        String paymentMethod =
                request.getParameter("paymentMethod");

        /*
         * =================================================
         * 4. KIỂM TRA DỮ LIỆU
         * =================================================
         */

        if (receiverName == null
                || receiverName.trim().isEmpty()
                || receiverPhone == null
                || receiverPhone.trim().isEmpty()
                || receiverAddress == null
                || receiverAddress.trim().isEmpty()) {

            request.setAttribute(
                    "checkoutError",
                    "Vui lòng nhập đầy đủ thông tin nhận hàng.");

            request.getRequestDispatcher(
                    "/WEB-INF/views/checkout.jsp")
                    .forward(request, response);

            return;
        }

        /*
         * Chỉ hỗ trợ COD
         */
        if (!"COD".equals(paymentMethod)) {

            request.setAttribute(
                    "checkoutError",
                    "Phương thức thanh toán không hợp lệ.");

            request.getRequestDispatcher(
                    "/WEB-INF/views/checkout.jsp")
                    .forward(request, response);

            return;
        }

        /*
         * =================================================
         * 5. LẤY GIỎ HÀNG
         * =================================================
         */

        @SuppressWarnings("unchecked")
        List<CartItem_24162093> cart =
                (List<CartItem_24162093>)
                        session.getAttribute("cart");

        if (cart == null || cart.isEmpty()) {

            response.sendRedirect(
                    request.getContextPath() + "/cart");

            return;
        }

        /*
         * =================================================
         * 6. TẠO ĐƠN HÀNG
         * =================================================
         */

        int orderId =
                orderDAO.createOrder(
                        user.getId(),
                        receiverName.trim(),
                        receiverPhone.trim(),
                        receiverAddress.trim(),
                        paymentMethod,
                        cart);

        /*
         * =================================================
         * 7. KIỂM TRA KẾT QUẢ
         * =================================================
         */

        if (orderId <= 0) {

            request.setAttribute(
                    "checkoutError",
                    "Đặt hàng thất bại. Có thể sản phẩm không đủ số lượng.");

            request.getRequestDispatcher(
                    "/WEB-INF/views/checkout.jsp")
                    .forward(request, response);

            return;
        }

        /*
         * =================================================
         * 8. ĐẶT HÀNG THÀNH CÔNG
         * =================================================
         */

        /*
         * Xóa giỏ hàng sau khi database đã COMMIT thành công
         */
        session.removeAttribute("cart");

        /*
         * Lưu thông tin thành công
         */
        session.setAttribute(
                "orderSuccess",
                "Đặt hàng thành công!");

        session.setAttribute(
                "orderId",
                orderId);

        /*
         * Chuyển sang trang kết quả
         */
        response.sendRedirect(
                request.getContextPath()
                        + "/checkout-success");
    }
}