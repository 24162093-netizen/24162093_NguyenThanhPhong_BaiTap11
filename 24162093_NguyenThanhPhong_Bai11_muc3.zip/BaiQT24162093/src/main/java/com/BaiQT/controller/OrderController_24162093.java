package com.BaiQT.controller;

import java.io.IOException;
import java.util.List;

import com.BaiQT.dao.OrderDAO_24162093;
import com.BaiQT.dao.OrderDAOImpl_24162093;
import com.BaiQT.model.Order_24162093;
import com.BaiQT.model.User_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/orders")
public class OrderController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private OrderDAO_24162093 orderDAO;

    @Override
    public void init() throws ServletException {
        orderDAO = new OrderDAOImpl_24162093();
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        /*
         * =====================================================
         * 1. KIỂM TRA ĐĂNG NHẬP
         * =====================================================
         */

        User_24162093 account =
                (User_24162093) session.getAttribute("account");

        if (account == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login");

            return;
        }

        /*
         * =====================================================
         * 2. LẤY TRẠNG THÁI TỪ URL
         * =====================================================
         */

        String status =
                request.getParameter("status");

        List<Order_24162093> orders;

        /*
         * =====================================================
         * 3. NẾU KHÔNG CHỌN TRẠNG THÁI
         *    -> LẤY TẤT CẢ ĐƠN
         * =====================================================
         */

        if (status == null
                || status.trim().isEmpty()
                || status.equalsIgnoreCase("ALL")) {

            orders =
                    orderDAO.getOrdersByUserId(
                            account.getId());

        } else {

            /*
             * =================================================
             * 4. NẾU CÓ STATUS
             *    -> LỌC THEO TRẠNG THÁI
             * =================================================
             */

            orders =
                    orderDAO.getOrdersByUserIdAndStatus(
                            account.getId(),
                            status);
        }

        /*
         * =====================================================
         * 5. GỬI DỮ LIỆU SANG JSP
         * =====================================================
         */

        request.setAttribute(
                "orders",
                orders);

        request.setAttribute(
                "selectedStatus",
                status);

        /*
         * =====================================================
         * 6. HIỂN THỊ TRANG ORDERS
         * =====================================================
         */

        request.getRequestDispatcher(
                "/WEB-INF/views/orders.jsp")
                .forward(request, response);
    }
}