package com.BaiQT.controller;

import java.io.IOException;

import com.BaiQT.service.BookService_24162093;
import com.BaiQT.service.BookServiceImpl_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/admin/books/delete")
public class AdminBookDeleteController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private BookService_24162093 bookService;

    @Override
    public void init() throws ServletException {
        bookService = new BookServiceImpl_24162093();
    }

    private boolean checkAdmin(HttpServletRequest request,
                               HttpServletResponse response)
            throws IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("account") == null) {
            response.sendRedirect(
                request.getContextPath() + "/login"
            );
            return false;
        }

        com.BaiQT.model.User_24162093 user =
                (com.BaiQT.model.User_24162093)
                session.getAttribute("account");

        if (!user.isAdmin()) {
            response.sendRedirect(
                request.getContextPath() + "/home"
            );
            return false;
        }

        return true;
    }

    @Override
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        if (!checkAdmin(request, response)) {
            return;
        }

        String idParam = request.getParameter("id");

        if (idParam == null || idParam.trim().isEmpty()) {
            response.sendRedirect(
                request.getContextPath() + "/admin/books"
            );
            return;
        }

        try {

            int bookid = Integer.parseInt(idParam);

            bookService.deleteBook(bookid);

        } catch (NumberFormatException e) {

            e.printStackTrace();
        }

        response.sendRedirect(
            request.getContextPath() + "/admin/books"
        );
    }
}