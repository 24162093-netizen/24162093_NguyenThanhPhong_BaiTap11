package com.BaiQT.controller;

import java.io.IOException;

import com.BaiQT.model.User_24162093;
import com.BaiQT.service.UserService_24162093;
import com.BaiQT.service.UserServiceImpl_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(
    urlPatterns = "/login",
    initParams = {
        @WebInitParam(
            name = "loginPage",
            value = "/WEB-INF/views/login.jsp"
        )
    }
)
public class LoginController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserService_24162093 userService;

    @Override
    public void init() throws ServletException {
        userService = new UserServiceImpl_24162093();
    }

    // =========================
    // HIỂN THỊ TRANG LOGIN
    // =========================

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher(
                "/WEB-INF/views/login.jsp"
        ).forward(request, response);
    }

    // =========================
    // XỬ LÝ ĐĂNG NHẬP
    // =========================

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Kiểm tra dữ liệu nhập
        if (email == null || email.trim().isEmpty()
                || password == null || password.trim().isEmpty()) {

            request.setAttribute(
                    "error",
                    "Vui lòng nhập email và mật khẩu!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/login.jsp"
            ).forward(request, response);

            return;
        }

        email = email.trim();

        // =========================
        // KIỂM TRA EMAIL + PASSWORD
        // =========================

        User_24162093 user =
                userService.login(email, password);

        if (user == null) {

            request.setAttribute(
                    "error",
                    "Email hoặc mật khẩu không đúng!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/login.jsp"
            ).forward(request, response);

            return;
        }

        // =========================
        // KIỂM TRA ĐÃ XÁC THỰC OTP
        // =========================

        if (!user.isActive()) {

            // Lưu email để người dùng có thể nhập OTP
            HttpSession session = request.getSession();
            session.setAttribute("otpEmail", user.getEmail());

            request.setAttribute(
                    "error",
                    "Tài khoản chưa được xác thực OTP!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/login.jsp"
            ).forward(request, response);

            return;
        }

        // =========================
        // ĐĂNG NHẬP THÀNH CÔNG
        // =========================

        HttpSession session = request.getSession();

        session.setAttribute(
                "account",
                user
        );

        // =========================
        // PHÂN QUYỀN
        // =========================

        if (user.isAdmin()) {

            // Admin → trang quản trị
            response.sendRedirect(
                    request.getContextPath()
                    + "/admin/books"
            );

        } else {

            // User → trang chủ
            response.sendRedirect(
                    request.getContextPath()
                    + "/home"
            );
        }
    }
}