package com.BaiQT.controller;

import java.io.IOException;
import java.util.List;

import com.BaiQT.dao.OrderDAO_24162093;
import com.BaiQT.dao.OrderDAOImpl_24162093;
import com.BaiQT.model.Order_24162093;
import com.BaiQT.model.OrderDetail_24162093;
import com.BaiQT.model.User_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/order-detail")
public class OrderDetailController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private OrderDAO_24162093 orderDAO;

    @Override
    public void init() throws ServletException {
        orderDAO = new OrderDAOImpl_24162093();
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        // Kiểm tra đăng nhập
        User_24162093 account =
                (User_24162093) session.getAttribute("account");

        if (account == null) {
            response.sendRedirect(
                    request.getContextPath() + "/login"
            );
            return;
        }

        // Lấy orderId từ URL
        String orderIdParam =
                request.getParameter("orderId");

        if (orderIdParam == null || orderIdParam.isBlank()) {
            response.sendRedirect(
                    request.getContextPath() + "/orders"
            );
            return;
        }

        int orderId;

        try {
            orderId = Integer.parseInt(orderIdParam);
        } catch (NumberFormatException e) {
            response.sendRedirect(
                    request.getContextPath() + "/orders"
            );
            return;
        }

        // Lấy thông tin đơn hàng
        Order_24162093 order =
                orderDAO.getOrderById(orderId);

        // Không tìm thấy đơn
        if (order == null) {
            response.sendRedirect(
                    request.getContextPath() + "/orders"
            );
            return;
        }

        /*
         * Kiểm tra đơn hàng có thuộc user đang đăng nhập không.
         * Tránh trường hợp user thay orderId trên URL
         * để xem đơn hàng của người khác.
         */
        if (order.getUserId() != account.getId()) {
            response.sendRedirect(
                    request.getContextPath() + "/orders"
            );
            return;
        }

        // Lấy các sản phẩm trong đơn hàng
        List<OrderDetail_24162093> details =
                orderDAO.getOrderDetailsByOrderId(orderId);

        // Gửi dữ liệu sang JSP
        request.setAttribute("order", order);
        request.setAttribute("details", details);

        // Hiển thị trang chi tiết đơn
        request.getRequestDispatcher(
                "/WEB-INF/views/order-detail.jsp"
        ).forward(request, response);
    }
}