package com.BaiQT.controller;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

import com.BaiQT.model.Book_24162093;
import com.BaiQT.model.User_24162093;
import com.BaiQT.service.BookService_24162093;
import com.BaiQT.service.BookServiceImpl_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

@WebServlet("/admin/books/add")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,
    maxFileSize = 5 * 1024 * 1024,
    maxRequestSize = 10 * 1024 * 1024
)
public class AdminBookAddController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private BookService_24162093 bookService;

    @Override
    public void init() throws ServletException {
        bookService = new BookServiceImpl_24162093();
    }

    // =========================
    // KIỂM TRA ADMIN
    // =========================

    private boolean checkAdmin(
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException {

        HttpSession session = request.getSession(false);

        if (session == null
                || session.getAttribute("account") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login"
            );

            return false;
        }

        User_24162093 user =
                (User_24162093) session.getAttribute("account");

        if (!user.isAdmin()) {

            response.sendRedirect(
                    request.getContextPath() + "/home"
            );

            return false;
        }

        return true;
    }

    // =========================
    // HIỂN THỊ FORM
    // =========================

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        if (!checkAdmin(request, response)) {
            return;
        }

        request.getRequestDispatcher(
                "/WEB-INF/views/admin/book-form.jsp"
        ).forward(request, response);
    }

    // =========================
    // THÊM SÁCH + UPLOAD ẢNH
    // =========================

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        if (!checkAdmin(request, response)) {
            return;
        }

        request.setCharacterEncoding("UTF-8");

        try {

            String isbnParam =
                    request.getParameter("isbn");

            String title =
                    request.getParameter("title");

            String publisher =
                    request.getParameter("publisher");

            String priceParam =
                    request.getParameter("price");

            String description =
                    request.getParameter("description");

            String publishDateParam =
                    request.getParameter("publishDate");

            String quantityParam =
                    request.getParameter("quantity");

            // =========================
            // LẤY FILE ẢNH
            // =========================

            Part imagePart =
                    request.getPart("coverImage");

            String coverImage = null;

            if (imagePart != null
                    && imagePart.getSize() > 0) {

                String originalName =
                        imagePart.getSubmittedFileName();

                String extension = "";

                if (originalName != null
                        && originalName.contains(".")) {

                    extension =
                            originalName.substring(
                                    originalName.lastIndexOf(".")
                            );
                }

                // Chỉ cho phép các định dạng ảnh
                extension = extension.toLowerCase();

                if (!extension.equals(".jpg")
                        && !extension.equals(".jpeg")
                        && !extension.equals(".png")
                        && !extension.equals(".gif")
                        && !extension.equals(".webp")) {

                    request.setAttribute(
                            "error",
                            "Chỉ được upload file ảnh JPG, JPEG, PNG, GIF hoặc WEBP!"
                    );

                    request.getRequestDispatcher(
                            "/WEB-INF/views/admin/book-form.jsp"
                    ).forward(request, response);

                    return;
                }

                // Tạo tên file mới tránh trùng
                coverImage =
                        UUID.randomUUID().toString()
                        + extension;

                String uploadPath =
                        getServletContext()
                                .getRealPath("/images");

                File uploadDir =
                        new File(uploadPath);

                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }

                String filePath =
                        uploadPath
                        + File.separator
                        + coverImage;

                imagePart.write(filePath);
            }

            // =========================
            // XỬ LÝ DỮ LIỆU
            // =========================

            int isbn =
                    Integer.parseInt(isbnParam);

            BigDecimal price =
                    new BigDecimal(priceParam);

            int quantity =
                    Integer.parseInt(quantityParam);

            LocalDate publishDate = null;

            if (publishDateParam != null
                    && !publishDateParam.trim().isEmpty()) {

                publishDate =
                        LocalDate.parse(
                                publishDateParam
                        );
            }

            // =========================
            // TẠO BOOK
            // =========================

            Book_24162093 book =
                    new Book_24162093();

            book.setIsbn(isbn);
            book.setTitle(title);
            book.setPublisher(publisher);
            book.setPrice(price);
            book.setDescription(description);
            book.setPublishDate(publishDate);
            book.setCoverImage(coverImage);
            book.setQuantity(quantity);

            // =========================
            // INSERT DATABASE
            // =========================

            boolean success =
                    bookService.addBook(book);

            if (success) {

                response.sendRedirect(
                        request.getContextPath()
                        + "/admin/books"
                );

            } else {

                // Nếu insert DB thất bại
                // xóa file ảnh vừa upload
                if (coverImage != null) {

                    String uploadPath =
                            getServletContext()
                                    .getRealPath("/images");

                    File imageFile =
                            new File(
                                    uploadPath,
                                    coverImage
                            );

                    if (imageFile.exists()) {
                        imageFile.delete();
                    }
                }

                request.setAttribute(
                        "error",
                        "Thêm sách thất bại!"
                );

                request.getRequestDispatcher(
                        "/WEB-INF/views/admin/book-form.jsp"
                ).forward(request, response);
            }

        } catch (Exception e) {

            e.printStackTrace();

            request.setAttribute(
                    "error",
                    "Dữ liệu nhập vào không hợp lệ!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/admin/book-form.jsp"
            ).forward(request, response);
        }
    }
}