package com.BaiQT.controller;

import java.io.IOException;
import java.util.List;

import com.BaiQT.model.Book_24162093;
import com.BaiQT.model.Rating_24162093;
import com.BaiQT.service.BookService_24162093;
import com.BaiQT.service.BookServiceImpl_24162093;
import com.BaiQT.service.RatingService_24162093;
import com.BaiQT.service.RatingServiceImpl_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/book-detail")
public class BookDetailController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private BookService_24162093 bookService;
    private RatingService_24162093 ratingService;

    @Override
    public void init() throws ServletException {
        bookService = new BookServiceImpl_24162093();
        ratingService = new RatingServiceImpl_24162093();
    }

    @Override
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("id");

        if (idParam == null || idParam.trim().isEmpty()) {
            response.sendRedirect(
                request.getContextPath() + "/home"
            );
            return;
        }

        int bookid;

        try {
            bookid = Integer.parseInt(idParam);
        } catch (NumberFormatException e) {
            response.sendRedirect(
                request.getContextPath() + "/home"
            );
            return;
        }

        Book_24162093 book = bookService.getBookById(bookid);

        if (book == null) {
            response.sendRedirect(
                request.getContextPath() + "/home"
            );
            return;
        }

        List<Rating_24162093> reviews =
                ratingService.getReviewsByBookId(bookid, 10);

        request.setAttribute("book", book);
        request.setAttribute("reviews", reviews);

        request.getRequestDispatcher(
            "/WEB-INF/views/book-detail.jsp"
        ).forward(request, response);
    }
}