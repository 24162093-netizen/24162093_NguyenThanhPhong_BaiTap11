package com.BaiQT.controller;

import java.io.IOException;

import com.BaiQT.service.UserService_24162093;
import com.BaiQT.service.UserServiceImpl_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/verify-otp")
public class VerifyOTPController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserService_24162093 userService;

    @Override
    public void init() throws ServletException {
        userService = new UserServiceImpl_24162093();
    }

    // Hiển thị form nhập OTP
    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String email = (String) session.getAttribute("otpEmail");

        if (email == null) {
            response.sendRedirect(
                    request.getContextPath() + "/register"
            );
            return;
        }

        request.getRequestDispatcher(
                "/WEB-INF/views/verify-otp.jsp"
        ).forward(request, response);
    }

    // Xử lý OTP
    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();

        String email = (String) session.getAttribute("otpEmail");
        String otp = request.getParameter("otp");

        if (email == null) {
            response.sendRedirect(
                    request.getContextPath() + "/register"
            );
            return;
        }

        if (otp == null || otp.trim().isEmpty()) {

            request.setAttribute(
                    "error",
                    "Vui lòng nhập mã OTP!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/verify-otp.jsp"
            ).forward(request, response);

            return;
        }

        otp = otp.trim();

        boolean verified =
                userService.verifyOTP(email, otp);

        if (verified) {

            session.removeAttribute("otpEmail");

            request.setAttribute(
                    "message",
                    "Xác thực tài khoản thành công! Bạn có thể đăng nhập."
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/login.jsp"
            ).forward(request, response);

        } else {

            request.setAttribute(
                    "error",
                    "Mã OTP không đúng hoặc đã hết hạn!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/verify-otp.jsp"
            ).forward(request, response);
        }
    }
}