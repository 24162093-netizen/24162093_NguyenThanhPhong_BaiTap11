package com.BaiQT.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/checkout-success")
public class CheckoutSuccessController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        // Kiểm tra người dùng đã đăng nhập chưa
        if (session.getAttribute("account") == null) {
            response.sendRedirect(
                request.getContextPath() + "/login"
            );
            return;
        }

        // Kiểm tra có đơn hàng vừa đặt thành công hay không
        Object orderSuccess = session.getAttribute("orderSuccess");

        if (orderSuccess == null) {
            response.sendRedirect(
                request.getContextPath() + "/home"
            );
            return;
        }

        // Lấy mã đơn hàng
        Object orderId = session.getAttribute("orderId");

        // Đưa mã đơn hàng sang JSP
        request.setAttribute("orderId", orderId);

        // Hiển thị trang đặt hàng thành công
        request.getRequestDispatcher(
            "/WEB-INF/views/checkout-success.jsp"
        ).forward(request, response);

        // Xóa thông tin thành công sau khi đã hiển thị
        session.removeAttribute("orderSuccess");
        session.removeAttribute("orderId");
    }
}