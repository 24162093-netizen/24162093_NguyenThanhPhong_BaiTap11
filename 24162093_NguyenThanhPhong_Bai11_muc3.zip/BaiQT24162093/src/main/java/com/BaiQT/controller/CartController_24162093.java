package com.BaiQT.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.BaiQT.model.Book_24162093;
import com.BaiQT.model.CartItem_24162093;
import com.BaiQT.service.BookService_24162093;
import com.BaiQT.service.BookServiceImpl_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/cart")
public class CartController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    /*
     * Dùng interface làm kiểu dữ liệu
     * và dùng BookServiceImpl để khởi tạo
     */
    private BookService_24162093 bookService;

    @Override
    public void init() {
        bookService = new BookServiceImpl_24162093();
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        /*
         * Chưa đăng nhập thì không được vào giỏ hàng
         */
        if (session == null || session.getAttribute("account") == null) {
            response.sendRedirect(
                    request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        /*
         * /cart
         * Không có action -> mở trang giỏ hàng
         */
        if (action == null || action.isEmpty()) {

            request.getRequestDispatcher(
                    "/WEB-INF/views/cart.jsp")
                    .forward(request, response);

            return;
        }

        switch (action) {

            case "add":
                addToCart(request, response, session);
                break;

            case "increase":
                increaseQuantity(request, response, session);
                break;

            case "decrease":
                decreaseQuantity(request, response, session);
                break;

            case "remove":
                removeFromCart(request, response, session);
                break;

            default:
                response.sendRedirect(
                        request.getContextPath() + "/cart");
                break;
        }
    }

    /*
     * =====================================================
     * THÊM SÁCH VÀO GIỎ
     * =====================================================
     */
    private void addToCart(
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session)
            throws IOException {

        int bookid = getBookId(request);

        if (bookid <= 0) {
            response.sendRedirect(
                    request.getContextPath() + "/cart");
            return;
        }

        /*
         * Lấy thông tin sách mới nhất từ database
         */
        Book_24162093 book =
                bookService.getBookById(bookid);

        if (book == null) {
            response.sendRedirect(
                    request.getContextPath() + "/cart");
            return;
        }

        /*
         * Sách hết hàng
         */
        if (book.getQuantity() <= 0) {

            session.setAttribute(
                    "cartMessage",
                    "⚠ Sản phẩm đã hết hàng.");

            response.sendRedirect(
                    request.getContextPath() + "/cart");

            return;
        }

        List<CartItem_24162093> cart =
                getCart(session);

        CartItem_24162093 existingItem = null;

        /*
         * Kiểm tra sách đã có trong giỏ chưa
         */
        for (CartItem_24162093 item : cart) {

            if (item.getBook().getBookid() == bookid) {
                existingItem = item;
                break;
            }
        }

        if (existingItem != null) {

            int currentQuantity =
                    existingItem.getQuantity();

            /*
             * Không cho vượt quá số lượng tồn kho
             */
            if (currentQuantity >= book.getQuantity()) {

                session.setAttribute(
                        "cartMessage",
                        "⚠ Không đủ số lượng. Chỉ còn "
                                + book.getQuantity()
                                + " sản phẩm trong kho.");

                response.sendRedirect(
                        request.getContextPath() + "/cart");

                return;
            }

            /*
             * Tăng số lượng lên 1
             */
            existingItem.setQuantity(
                    currentQuantity + 1);

            /*
             * Cập nhật thông tin sách mới nhất
             */
            existingItem.setBook(book);

        } else {

            /*
             * Sách chưa có trong giỏ -> thêm mới với SL = 1
             */
            cart.add(
                    new CartItem_24162093(book, 1));
        }

        session.setAttribute("cart", cart);

        response.sendRedirect(
                request.getContextPath() + "/cart");
    }

    /*
     * =====================================================
     * TĂNG SỐ LƯỢNG
     * =====================================================
     */
    private void increaseQuantity(
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session)
            throws IOException {

        int bookid = getBookId(request);

        List<CartItem_24162093> cart =
                getCart(session);

        /*
         * Lấy tồn kho mới nhất
         */
        Book_24162093 latestBook =
                bookService.getBookById(bookid);

        if (latestBook == null) {

            response.sendRedirect(
                    request.getContextPath() + "/cart");

            return;
        }

        for (CartItem_24162093 item : cart) {

            if (item.getBook().getBookid() == bookid) {

                int currentQuantity =
                        item.getQuantity();

                int stock =
                        latestBook.getQuantity();

                /*
                 * Đã đạt số lượng tối đa
                 */
                if (currentQuantity >= stock) {

                    session.setAttribute(
                            "cartMessage",
                            "⚠ Không đủ số lượng. Chỉ còn "
                                    + stock
                                    + " sản phẩm trong kho.");

                    response.sendRedirect(
                            request.getContextPath() + "/cart");

                    return;
                }

                /*
                 * Tăng thêm 1
                 */
                item.setQuantity(
                        currentQuantity + 1);

                /*
                 * Cập nhật sách mới nhất
                 */
                item.setBook(latestBook);

                break;
            }
        }

        session.setAttribute("cart", cart);

        response.sendRedirect(
                request.getContextPath() + "/cart");
    }

    /*
     * =====================================================
     * GIẢM SỐ LƯỢNG
     * =====================================================
     */
    private void decreaseQuantity(
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session)
            throws IOException {

        int bookid = getBookId(request);

        List<CartItem_24162093> cart =
                getCart(session);

        for (CartItem_24162093 item : cart) {

            if (item.getBook().getBookid() == bookid) {

                int currentQuantity =
                        item.getQuantity();

                /*
                 * Không giảm xuống 0
                 */
                if (currentQuantity > 1) {

                    item.setQuantity(
                            currentQuantity - 1);
                }

                break;
            }
        }

        session.setAttribute("cart", cart);

        response.sendRedirect(
                request.getContextPath() + "/cart");
    }

    /*
     * =====================================================
     * XÓA SẢN PHẨM KHỎI GIỎ
     * =====================================================
     */
    private void removeFromCart(
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session)
            throws IOException {

        int bookid = getBookId(request);

        List<CartItem_24162093> cart =
                getCart(session);

        cart.removeIf(
                item ->
                        item.getBook().getBookid() == bookid);

        session.setAttribute("cart", cart);

        response.sendRedirect(
                request.getContextPath() + "/cart");
    }

    /*
     * =====================================================
     * LẤY CART TỪ SESSION
     * =====================================================
     */
    @SuppressWarnings("unchecked")
    private List<CartItem_24162093> getCart(
            HttpSession session) {

        Object cartObject =
                session.getAttribute("cart");

        /*
         * Chưa có cart -> tạo cart mới
         */
        if (cartObject == null) {

            List<CartItem_24162093> cart =
                    new ArrayList<>();

            session.setAttribute(
                    "cart",
                    cart);

            return cart;
        }

        return (List<CartItem_24162093>) cartObject;
    }

    /*
     * =====================================================
     * LẤY BOOK ID
     * =====================================================
     */
    private int getBookId(
            HttpServletRequest request) {

        try {

            return Integer.parseInt(
                    request.getParameter("bookid"));

        } catch (Exception e) {

            return -1;
        }
    }
}