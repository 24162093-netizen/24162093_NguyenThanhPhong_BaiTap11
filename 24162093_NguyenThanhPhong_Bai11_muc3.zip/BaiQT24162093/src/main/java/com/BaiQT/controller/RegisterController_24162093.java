package com.BaiQT.controller;

import java.io.IOException;
import java.time.LocalDateTime;

import com.BaiQT.model.User_24162093;
import com.BaiQT.service.EmailService_24162093;
import com.BaiQT.service.UserService_24162093;
import com.BaiQT.service.UserServiceImpl_24162093;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterController_24162093 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserService_24162093 userService;
    private EmailService_24162093 emailService;

    @Override
    public void init() throws ServletException {

        userService = new UserServiceImpl_24162093();
        emailService = new EmailService_24162093();
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher(
                "/WEB-INF/views/register.jsp"
        ).forward(request, response);
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String email = request.getParameter("email");
        String fullname = request.getParameter("fullname");
        String phoneParam = request.getParameter("phone");
        String password = request.getParameter("password");

        // =========================
        // KIỂM TRA DỮ LIỆU
        // =========================

        if (email == null || email.trim().isEmpty()
                || fullname == null || fullname.trim().isEmpty()
                || password == null || password.trim().isEmpty()) {

            request.setAttribute(
                    "error",
                    "Vui lòng nhập đầy đủ thông tin!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/register.jsp"
            ).forward(request, response);

            return;
        }

        // =========================
        // KIỂM TRA EMAIL
        // =========================

        email = email.trim();

        if (!email.matches(
                "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {

            request.setAttribute(
                    "error",
                    "Email không hợp lệ!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/register.jsp"
            ).forward(request, response);

            return;
        }

        // =========================
        // XỬ LÝ PHONE
        // =========================

        int phone = 0;

        if (phoneParam != null
                && !phoneParam.trim().isEmpty()) {

            try {

                phone = Integer.parseInt(
                        phoneParam.trim()
                );

            } catch (NumberFormatException e) {

                request.setAttribute(
                        "error",
                        "Số điện thoại không hợp lệ!"
                );

                request.getRequestDispatcher(
                        "/WEB-INF/views/register.jsp"
                ).forward(request, response);

                return;
            }
        }

        // =========================
        // TẠO USER
        // =========================

        User_24162093 user = new User_24162093();

        user.setEmail(email);
        user.setFullname(fullname.trim());
        user.setPhone(phone);
        user.setPasswd(password);
        user.setSignupDate(LocalDateTime.now());
        user.setAdmin(false);

        // =========================
        // ĐĂNG KÝ USER
        // =========================

        boolean success = userService.register(user);

        if (!success) {

            request.setAttribute(
                    "error",
                    "Email đã tồn tại hoặc đăng ký thất bại!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/register.jsp"
            ).forward(request, response);

            return;
        }

        // =========================
        // TÌM USER VỪA TẠO
        // =========================

        User_24162093 newUser =
                userService.findByEmail(email);

        if (newUser == null) {

            request.setAttribute(
                    "error",
                    "Không tìm thấy tài khoản vừa đăng ký!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/register.jsp"
            ).forward(request, response);

            return;
        }

        // =========================
        // TẠO OTP
        // =========================

        String otp = emailService.generateOTP();

        // OTP có hiệu lực 5 phút
        LocalDateTime expire =
                LocalDateTime.now().plusMinutes(5);

        // =========================
        // LƯU OTP VÀO DATABASE
        // =========================

        userService.updateOTP(
                newUser.getId(),
                otp,
                expire
        );

        // =========================
        // GỬI EMAIL OTP
        // =========================

        boolean emailSent =
                emailService.sendOTP(
                        email,
                        otp
                );

        if (!emailSent) {

            request.setAttribute(
                    "error",
                    "Đăng ký thành công nhưng không gửi được OTP. "
                    + "Vui lòng kiểm tra cấu hình Gmail!"
            );

            request.getRequestDispatcher(
                    "/WEB-INF/views/register.jsp"
            ).forward(request, response);

            return;
        }

        // =========================
        // LƯU EMAIL VÀO SESSION
        // =========================

        request.getSession().setAttribute(
                "otpEmail",
                email
        );

        // =========================
        // CHUYỂN SANG TRANG NHẬP OTP
        // =========================

        response.sendRedirect(
                request.getContextPath()
                + "/verify-otp"
        );
    }
}