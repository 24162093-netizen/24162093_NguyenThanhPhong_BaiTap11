package com.BaiQT.service;

import java.util.List;

import com.BaiQT.model.BookAuthor_24162093;

public interface BookAuthorService_24162093 {

    List<BookAuthor_24162093> getAuthorsByBookId(int bookid);

    List<BookAuthor_24162093> getBooksByAuthorId(int authorId);

    boolean addBookAuthor(BookAuthor_24162093 bookAuthor);

    boolean deleteBookAuthor(int bookid, int authorId);

    boolean deleteByBookId(int bookid);
}