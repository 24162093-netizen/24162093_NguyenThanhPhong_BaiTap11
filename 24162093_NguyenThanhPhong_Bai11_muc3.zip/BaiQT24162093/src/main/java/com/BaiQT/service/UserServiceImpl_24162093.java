package com.BaiQT.service;

import java.time.LocalDateTime;

import com.BaiQT.dao.UserDAO_24162093;
import com.BaiQT.dao.UserDAOImpl_24162093;
import com.BaiQT.model.User_24162093;

public class UserServiceImpl_24162093
        implements UserService_24162093 {

    private UserDAO_24162093 userDAO;

    public UserServiceImpl_24162093() {
        userDAO = new UserDAOImpl_24162093();
    }

    @Override
    public User_24162093 login(String email, String password) {

        User_24162093 user = userDAO.findByEmail(email);

        if (user != null
                && user.getPasswd().equals(password)) {

            user.setLastLogin(LocalDateTime.now());
            userDAO.update(user);

            return user;
        }

        return null;
    }

    @Override
    public boolean register(User_24162093 user) {

        User_24162093 existing =
                userDAO.findByEmail(user.getEmail());

        if (existing != null) {
            return false;
        }

        return userDAO.insert(user);
    }

    @Override
    public User_24162093 findByEmail(String email) {
        return userDAO.findByEmail(email);
    }

    @Override
    public User_24162093 findById(int id) {
        return userDAO.findById(id);
    }

    @Override
    public boolean update(User_24162093 user) {
        return userDAO.update(user);
    }

    // =========================
    // OTP
    // =========================

    @Override
    public void updateOTP(
            int userId,
            String otp,
            LocalDateTime expire) {

        userDAO.updateOTP(
                userId,
                otp,
                expire
        );
    }

    @Override
    public boolean verifyOTP(
            String email,
            String otp) {

        return userDAO.verifyOTP(
                email,
                otp
        );
    }
}