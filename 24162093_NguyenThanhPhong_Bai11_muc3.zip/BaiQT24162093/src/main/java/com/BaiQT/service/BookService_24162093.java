package com.BaiQT.service;

import java.util.List;


import com.BaiQT.model.Book_24162093;

public interface BookService_24162093 {

    List<Book_24162093> getAllBooks();

    List<Book_24162093> getBooksByPage(int page, int pageSize);

    Book_24162093 getBookById(int bookid);

    boolean addBook(Book_24162093 book);

    boolean updateBook(Book_24162093 book);

    boolean deleteBook(int bookid);

    int getTotalBooks();

    int getTotalPages(int pageSize);
}