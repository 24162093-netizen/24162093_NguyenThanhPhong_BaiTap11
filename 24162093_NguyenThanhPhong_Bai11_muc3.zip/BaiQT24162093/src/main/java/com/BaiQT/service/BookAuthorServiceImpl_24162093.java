package com.BaiQT.service;

import java.util.List;

import com.BaiQT.dao.BookAuthorDAO_24162093;
import com.BaiQT.dao.BookAuthorDAOImpl_24162093;
import com.BaiQT.model.BookAuthor_24162093;

public class BookAuthorServiceImpl_24162093 implements BookAuthorService_24162093 {

    private final BookAuthorDAO_24162093 bookAuthorDAO;

    public BookAuthorServiceImpl_24162093() {
        this.bookAuthorDAO = new BookAuthorDAOImpl_24162093();
    }

    @Override
    public List<BookAuthor_24162093> getAuthorsByBookId(int bookid) {
        return bookAuthorDAO.findByBookId(bookid);
    }

    @Override
    public List<BookAuthor_24162093> getBooksByAuthorId(int authorId) {
        return bookAuthorDAO.findByAuthorId(authorId);
    }

    @Override
    public boolean addBookAuthor(BookAuthor_24162093 bookAuthor) {
        if (bookAuthor == null) {
            return false;
        }

        return bookAuthorDAO.insert(bookAuthor);
    }

    @Override
    public boolean deleteBookAuthor(int bookid, int authorId) {
        return bookAuthorDAO.delete(bookid, authorId);
    }

    @Override
    public boolean deleteByBookId(int bookid) {
        return bookAuthorDAO.deleteByBookId(bookid);
    }
}