package com.BaiQT.service;

import java.util.List;

import com.BaiQT.model.Author_24162093;

public interface AuthorService_24162093 {

    List<Author_24162093> getAllAuthors();

    Author_24162093 getAuthorById(int authorId);

    boolean addAuthor(Author_24162093 author);

    boolean updateAuthor(Author_24162093 author);

    boolean deleteAuthor(int authorId);
}