package com.BaiQT.service;

import java.util.List;

import com.BaiQT.dao.RatingDAO_24162093;
import com.BaiQT.dao.RatingDAOImpl_24162093;
import com.BaiQT.model.Rating_24162093;

public class RatingServiceImpl_24162093 implements RatingService_24162093 {

    private final RatingDAO_24162093 ratingDAO;

    public RatingServiceImpl_24162093() {
        this.ratingDAO = new RatingDAOImpl_24162093();
    }

    @Override
    public List<Rating_24162093> getReviewsByBookId(int bookid) {
        return ratingDAO.findByBookId(bookid);
    }

    @Override
    public List<Rating_24162093> getReviewsByBookId(int bookid, int limit) {

        if (limit <= 0) {
            limit = 10;
        }

        return ratingDAO.findByBookId(bookid, limit);
    }

    @Override
    public Rating_24162093 getReview(int userid, int bookid) {
        return ratingDAO.findByUserAndBook(userid, bookid);
    }

    @Override
    public boolean addReview(Rating_24162093 rating) {

        if (rating == null) {
            return false;
        }

        return ratingDAO.insert(rating);
    }

    @Override
    public boolean updateReview(Rating_24162093 rating) {

        if (rating == null) {
            return false;
        }

        return ratingDAO.update(rating);
    }

    @Override
    public boolean deleteReview(int userid, int bookid) {
        return ratingDAO.delete(userid, bookid);
    }
}