package com.BaiQT.service;

import java.util.Properties;
import java.util.Random;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class EmailService_24162093 {

    // Gmail dùng để gửi OTP
    private static final String FROM_EMAIL = "nguyenthanhphong2000bg@gmail.com";

    // Mật khẩu ứng dụng Gmail 16 ký tự
    private static final String APP_PASSWORD = "kaeskqwumxjbodsu";

    /**
     * Tạo OTP 6 số
     */
    public String generateOTP() {
        Random random = new Random();
        return String.format("%06d", random.nextInt(1000000));
    }

    /**
     * Gửi OTP đến email người đăng ký
     */
    public boolean sendOTP(String toEmail, String otp) {

        Properties properties = new Properties();

        properties.put(
                "mail.smtp.auth",
                "true"
        );

        properties.put(
                "mail.smtp.starttls.enable",
                "true"
        );

        properties.put(
                "mail.smtp.host",
                "smtp.gmail.com"
        );

        properties.put(
                "mail.smtp.port",
                "587"
        );

        Session session = Session.getInstance(
                properties,
                new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(
                                FROM_EMAIL,
                                APP_PASSWORD
                        );
                    }
                }
        );

        try {

            Message message = new MimeMessage(session);

            message.setFrom(
                    new InternetAddress(FROM_EMAIL)
            );

            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(toEmail)
            );

            message.setSubject(
                    "Mã OTP kích hoạt tài khoản - Website Bán Sách"
            );

            message.setText(
                    "Xin chào,\n\n"
                    + "Mã OTP kích hoạt tài khoản của bạn là:\n\n"
                    + otp
                    + "\n\n"
                    + "Mã OTP có hiệu lực trong 5 phút."
                    + "\n\n"
                    + "Nếu bạn không thực hiện đăng ký tài khoản, "
                    + "vui lòng bỏ qua email này.\n\n"
                    + "Website Bán Sách"
            );

            Transport.send(message);

            return true;

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }
}