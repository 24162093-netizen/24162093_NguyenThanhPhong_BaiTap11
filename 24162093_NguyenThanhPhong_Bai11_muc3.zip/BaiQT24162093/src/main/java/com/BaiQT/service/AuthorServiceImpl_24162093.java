package com.BaiQT.service;

import java.util.List;

import com.BaiQT.dao.AuthorDAO_24162093;
import com.BaiQT.dao.AuthorDAOImpl_24162093;
import com.BaiQT.model.Author_24162093;

public class AuthorServiceImpl_24162093 implements AuthorService_24162093 {

    private final AuthorDAO_24162093 authorDAO;

    public AuthorServiceImpl_24162093() {
        this.authorDAO = new AuthorDAOImpl_24162093();
    }

    @Override
    public List<Author_24162093> getAllAuthors() {
        return authorDAO.findAll();
    }

    @Override
    public Author_24162093 getAuthorById(int authorId) {
        return authorDAO.findById(authorId);
    }

    @Override
    public boolean addAuthor(Author_24162093 author) {

        if (author == null) {
            return false;
        }

        return authorDAO.insert(author);
    }

    @Override
    public boolean updateAuthor(Author_24162093 author) {

        if (author == null) {
            return false;
        }

        return authorDAO.update(author);
    }

    @Override
    public boolean deleteAuthor(int authorId) {
        return authorDAO.delete(authorId);
    }
}