package com.BaiQT.service;

import java.util.List;

import com.BaiQT.model.Rating_24162093;

public interface RatingService_24162093 {

    List<Rating_24162093> getReviewsByBookId(int bookid);

    List<Rating_24162093> getReviewsByBookId(int bookid, int limit);

    Rating_24162093 getReview(int userid, int bookid);

    boolean addReview(Rating_24162093 rating);

    boolean updateReview(Rating_24162093 rating);

    boolean deleteReview(int userid, int bookid);
}