package com.BaiQT.service;

import java.util.List;

import com.BaiQT.dao.BookDAO_24162093;
import com.BaiQT.dao.BookDAOImpl_24162093;
import com.BaiQT.model.Book_24162093;

public class BookServiceImpl_24162093 implements BookService_24162093 {

    private final BookDAO_24162093 bookDAO;

    public BookServiceImpl_24162093() {
        this.bookDAO = new BookDAOImpl_24162093();
    }

    @Override
    public List<Book_24162093> getAllBooks() {
        return bookDAO.findAll();
    }

    @Override
    public List<Book_24162093> getBooksByPage(int page, int pageSize) {

        if (page < 1) {
            page = 1;
        }

        if (pageSize <= 0) {
            pageSize = 3;
        }

        return bookDAO.findAll(page, pageSize);
    }

    @Override
    public Book_24162093 getBookById(int bookid) {
        return bookDAO.findById(bookid);
    }

    @Override
    public boolean addBook(Book_24162093 book) {

        if (book == null) {
            return false;
        }

        return bookDAO.insert(book);
    }

    @Override
    public boolean updateBook(Book_24162093 book) {

        if (book == null) {
            return false;
        }

        return bookDAO.update(book);
    }

    @Override
    public boolean deleteBook(int bookid) {
        return bookDAO.delete(bookid);
    }

    @Override
    public int getTotalBooks() {
        return bookDAO.countBooks();
    }

    @Override
    public int getTotalPages(int pageSize) {

        if (pageSize <= 0) {
            pageSize = 3;
        }

        int totalBooks = bookDAO.countBooks();

        return (int) Math.ceil((double) totalBooks / pageSize);
    }
}