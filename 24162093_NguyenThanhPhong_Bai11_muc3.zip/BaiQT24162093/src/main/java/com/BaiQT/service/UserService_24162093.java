package com.BaiQT.service;

import java.time.LocalDateTime;

import com.BaiQT.model.User_24162093;

public interface UserService_24162093 {

    User_24162093 login(String email, String password);

    boolean register(User_24162093 user);

    User_24162093 findById(int id);

    User_24162093 findByEmail(String email);

    boolean update(User_24162093 user);

    void updateOTP(
            int userId,
            String otp,
            LocalDateTime expire
    );

    boolean verifyOTP(
            String email,
            String otp
    );
}