<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<!DOCTYPE html>
<html lang="vi">

<head>

<meta charset="UTF-8">

<title>Quản lý sách</title>

<style>
* {
	box-sizing: border-box;
}

body {
	margin: 0;
	font-family: Arial, sans-serif;
	background: #f4f6f8;
	color: #333;
}

/* =========================
           CONTAINER
           ========================= */
.container {
	width: 1100px;
	max-width: 95%;
	margin: 30px auto;
	background: white;
	padding: 25px;
	border-radius: 12px;
	box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
}

/* =========================
           HEADER
           ========================= */
.page-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	margin-bottom: 25px;
}

.page-header h2 {
	margin: 0;
	color: #212529;
	font-size: 25px;
}

.add-btn {
	display: inline-block;
	padding: 11px 18px;
	background: #28a745;
	color: white;
	text-decoration: none;
	border-radius: 7px;
	font-weight: bold;
	transition: background-color 0.2s ease;
}

.add-btn:hover {
	background: #218838;
}

/* =========================
           TABLE
           ========================= */
.table-wrapper {
	overflow-x: auto;
}

table {
	width: 100%;
	border-collapse: collapse;
	background: white;
	table-layout: fixed;
}

th {
	background: #007bff;
	color: white;
	padding: 13px 10px;
	text-align: center;
	font-size: 14px;
	white-space: nowrap;
}

td {
	border-bottom: 1px solid #e9ecef;
	padding: 12px 10px;
	text-align: center;
	vertical-align: middle;
	font-size: 14px;
	height: 115px;
}

tbody tr:hover {
	background: #f8fbff;
}

/* =========================
           ẢNH BÌA
           ========================= */
.book-cover {
	width: 65px;
	height: 90px;
	object-fit: cover;
	display: block;
	margin: 0 auto;
	border-radius: 6px;
	border: 1px solid #ddd;
	box-shadow: 0 2px 7px rgba(0, 0, 0, 0.15);
	/* Không cho ảnh làm thay đổi kích thước bảng */
	flex-shrink: 0;
}

.no-image {
	width: 65px;
	height: 90px;
	margin: 0 auto;
	display: flex;
	align-items: center;
	justify-content: center;
	text-align: center;
	background: #f1f3f5;
	color: #868e96;
	border: 1px solid #ddd;
	border-radius: 6px;
	font-size: 11px;
}

/* =========================
           TÊN SÁCH
           ========================= */
.book-title {
	font-weight: bold;
	color: #212529;
	max-width: 190px;
	margin: auto;
	text-align: left;
	word-wrap: break-word;
}

/* =========================
           GIÁ
           ========================= */
.price {
	color: #dc3545;
	font-weight: bold;
	white-space: nowrap;
}

.quantity {
	font-weight: bold;
}

/* =========================
           ACTION
           ========================= */
.actions {
	white-space: nowrap;
}

.edit, .delete {
	display: inline-block;
	padding: 7px 11px;
	border-radius: 5px;
	text-decoration: none;
	font-size: 13px;
	font-weight: bold;
}

.edit {
	background: #e7f1ff;
	color: #007bff;
}

.edit:hover {
	background: #007bff;
	color: white;
}

.delete {
	background: #ffe8e8;
	color: #dc3545;
}

.delete:hover {
	background: #dc3545;
	color: white;
}

/* =========================
           PAGINATION
           ========================= */
.pagination {
	text-align: center;
	margin-top: 25px;
}

.pagination a, .pagination span {
	display: inline-block;
	min-width: 38px;
	padding: 9px 12px;
	margin: 3px;
	border-radius: 6px;
	text-decoration: none;
	border: 1px solid #dee2e6;
	font-size: 14px;
}

.pagination a {
	color: #007bff;
	background: white;
}

.pagination a:hover {
	background: #007bff;
	color: white;
}

.pagination .current {
	background: #007bff;
	color: white;
	border-color: #007bff;
	font-weight: bold;
}

/* =========================
           EMPTY
           ========================= */
.empty {
	padding: 30px;
	color: #777;
	text-align: center;
}
</style>

</head>

<body>

	<div class="container">

		<!-- =========================
         HEADER
         ========================= -->

		<div class="page-header">

			<h2>📚 Quản lý sách</h2>

			<a class="add-btn"
				href="${pageContext.request.contextPath}/admin/books/add"> +
				Thêm sách </a>

		</div>


		<!-- =========================
         TABLE
         ========================= -->

		<div class="table-wrapper">

			<table>

				<thead>

					<tr>

						<th style="width: 55px;">ID</th>

						<th style="width: 90px;">Ảnh bìa</th>

						<th style="width: 80px;">ISBN</th>

						<th style="width: 190px;">Tên sách</th>

						<th style="width: 130px;">Tác giả</th>

						<th style="width: 130px;">Nhà xuất bản</th>

						<th style="width: 100px;">Giá</th>

						<th style="width: 110px;">Ngày xuất bản</th>

						<th style="width: 80px;">Số lượng</th>

						<th style="width: 130px;">Thao tác</th>

					</tr>

				</thead>


				<tbody>

					<c:choose>

						<c:when test="${not empty books}">

							<c:forEach var="book" items="${books}">

								<tr>

									<!-- ID -->

									<td>${book.bookid}</td>


									<!-- ẢNH BÌA -->

									<td><c:choose>

											<c:when test="${not empty book.coverImage}">

												<img class="book-cover"
													src="${pageContext.request.contextPath}/images/${book.coverImage}?v=${book.bookid}"
													alt="${book.title}">

											</c:when>

											<c:otherwise>

												<div class="no-image">Chưa có ảnh</div>

											</c:otherwise>

										</c:choose></td>


									<!-- ISBN -->

									<td>${book.isbn}</td>


									<!-- TÊN -->

									<td>

										<div class="book-title">${book.title}</div>

									</td>


									<!-- TÁC GIẢ -->

									<td>${book.authorName}</td>


									<!-- NHÀ XUẤT BẢN -->

									<td>${book.publisher}</td>


									<!-- GIÁ -->

									<td class="price">${book.price} ₫</td>


									<!-- NGÀY -->

									<td>${book.publishDate}</td>


									<!-- SỐ LƯỢNG -->

									<td class="quantity">${book.quantity}</td>


									<!-- THAO TÁC -->

									<td class="actions"><a class="edit"
										href="${pageContext.request.contextPath}/admin/books/edit?id=${book.bookid}">
											Sửa </a> <a class="delete"
										href="${pageContext.request.contextPath}/admin/books/delete?id=${book.bookid}"
										onclick="return confirm('Bạn có chắc muốn xóa sách này?');">
											Xóa </a></td>

								</tr>

							</c:forEach>

						</c:when>


						<c:otherwise>

							<tr>

								<td colspan="10" class="empty">Chưa có sách nào trong hệ
									thống.</td>

							</tr>

						</c:otherwise>

					</c:choose>

				</tbody>

			</table>

		</div>


		<!-- =========================
         PHÂN TRANG
         ========================= -->

		<c:if test="${totalPages > 1}">

			<div class="pagination">

				<c:if test="${currentPage > 1}">

					<a
						href="${pageContext.request.contextPath}/admin/books?page=${currentPage - 1}">
						‹ Trước </a>

				</c:if>


				<c:forEach begin="1" end="${totalPages}" var="page">

					<c:choose>

						<c:when test="${page == currentPage}">

							<span class="current"> ${page} </span>

						</c:when>

						<c:otherwise>

							<a
								href="${pageContext.request.contextPath}/admin/books?page=${page}">
								${page} </a>

						</c:otherwise>

					</c:choose>

				</c:forEach>


				<c:if test="${currentPage < totalPages}">

					<a
						href="${pageContext.request.contextPath}/admin/books?page=${currentPage + 1}">
						Sau › </a>

				</c:if>

			</div>

		</c:if>

	</div>

</body>

</html>