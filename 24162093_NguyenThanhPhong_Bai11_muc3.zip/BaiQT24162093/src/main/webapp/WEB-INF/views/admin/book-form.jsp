<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">

<head>

    <meta charset="UTF-8">

    <title>
        ${empty book ? 'Thêm sách' : 'Sửa sách'}
    </title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
        }

        .container {
            width: 700px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 8px #ddd;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 12px;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input,
        textarea {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
        }

        textarea {
            min-height: 120px;
            resize: vertical;
        }

        .image-box {
            margin-top: 10px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: #fafafa;
        }

        .preview-image {
            display: block;
            width: 160px;
            height: 220px;
            object-fit: cover;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 10px;
        }

        .image-name {
            margin-top: 8px;
            color: #666;
            font-size: 14px;
        }

        .btn {
            margin-top: 20px;
            padding: 10px 18px;
            border: none;
            border-radius: 4px;
            color: white;
            background: #007bff;
            cursor: pointer;
        }

        .btn:hover {
            background: #0056b3;
        }

        .back {
            display: inline-block;
            margin-left: 10px;
            padding: 9px 18px;
            text-decoration: none;
            border-radius: 4px;
            background: #6c757d;
            color: white;
        }

        .error {
            color: red;
            margin-bottom: 15px;
            text-align: center;
        }

        .required {
            color: red;
        }

    </style>

</head>

<body>

<div class="container">

    <h2>
        ${empty book ? 'Thêm sách' : 'Sửa sách'}
    </h2>

    <!-- =========================
         HIỂN THỊ LỖI
         ========================= -->

    <c:if test="${not empty error}">

        <div class="error">
            ${error}
        </div>

    </c:if>


    <!-- =========================
         FORM
         ========================= -->

    <form
        action="${pageContext.request.contextPath}${empty book ? '/admin/books/add' : '/admin/books/edit'}"
        method="post"
        enctype="multipart/form-data">


        <!-- =========================
             ID KHI SỬA
             ========================= -->

        <c:if test="${not empty book}">

            <input
                type="hidden"
                name="bookid"
                value="${book.bookid}">

        </c:if>


        <!-- =========================
             ISBN
             ========================= -->

        <label>
            ISBN <span class="required">*</span>
        </label>

        <input
            type="number"
            name="isbn"
            value="${book.isbn}"
            required>


        <!-- =========================
             TÊN SÁCH
             ========================= -->

        <label>
            Tên sách <span class="required">*</span>
        </label>

        <input
            type="text"
            name="title"
            value="${book.title}"
            required>


        <!-- =========================
             NHÀ XUẤT BẢN
             ========================= -->

        <label>
            Nhà xuất bản <span class="required">*</span>
        </label>

        <input
            type="text"
            name="publisher"
            value="${book.publisher}"
            required>


        <!-- =========================
             GIÁ
             ========================= -->

        <label>
            Giá <span class="required">*</span>
        </label>

        <input
            type="number"
            name="price"
            step="0.01"
            value="${book.price}"
            required>


        <!-- =========================
             MÔ TẢ
             ========================= -->

        <label>
            Mô tả
        </label>

        <textarea
            name="description">${book.description}</textarea>


        <!-- =========================
             NGÀY XUẤT BẢN
             ========================= -->

        <label>
            Ngày xuất bản
        </label>

        <input
            type="date"
            name="publishDate"
            value="${book.publishDate}">


        <!-- =========================
             ẢNH BÌA
             ========================= -->

        <label>
            Ảnh bìa
            <c:if test="${empty book}">
                <span class="required">*</span>
            </c:if>
        </label>

        <div class="image-box">

            <input
                type="file"
                name="coverImage"
                accept="image/jpeg,image/png,image/gif,image/webp"
                onchange="previewImage(event)">

            <!-- Hiển thị ảnh cũ khi sửa -->

            <c:if test="${not empty book && not empty book.coverImage}">

                <div class="image-name">
                    Ảnh hiện tại: ${book.coverImage}
                </div>

                <img
                    id="preview"
                    class="preview-image"
                    src="${pageContext.request.contextPath}/images/${book.coverImage}"
                    alt="${book.title}"
                    onerror="this.style.display='none';">

            </c:if>


            <!-- Preview ảnh mới -->

            <c:if test="${empty book || empty book.coverImage}">

                <img
                    id="preview"
                    class="preview-image"
                    style="display:none;"
                    alt="Ảnh xem trước">

            </c:if>

        </div>


        <!-- =========================
             SỐ LƯỢNG
             ========================= -->

        <label>
            Số lượng <span class="required">*</span>
        </label>

        <input
            type="number"
            name="quantity"
            value="${book.quantity}"
            min="0"
            required>


        <!-- =========================
             BUTTON
             ========================= -->

        <button
            class="btn"
            type="submit">

            ${empty book ? 'Thêm sách' : 'Cập nhật'}

        </button>


        <a
            class="back"
            href="${pageContext.request.contextPath}/admin/books">

            Quay lại

        </a>

    </form>

</div>


<!-- =========================
     JAVASCRIPT PREVIEW ẢNH
     ========================= -->

<script>

function previewImage(event) {

    const file =
        event.target.files[0];

    const preview =
        document.getElementById("preview");

    if (file) {

        const reader =
            new FileReader();

        reader.onload = function(e) {

            preview.src =
                e.target.result;

            preview.style.display =
                "block";
        };

        reader.readAsDataURL(file);

    }
}

</script>

</body>

</html>