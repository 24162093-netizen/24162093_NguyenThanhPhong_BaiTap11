<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<div class="cart-page">

    <div class="cart-header">

        <div>
            <h2>🛒 Giỏ hàng của bạn</h2>
            <p>Kiểm tra sản phẩm trước khi thanh toán</p>
        </div>

        <a
            href="${pageContext.request.contextPath}/home"
            class="back-btn">
            ← Tiếp tục mua sắm
        </a>

    </div>


    <%-- Thông báo khi số lượng vượt quá tồn kho --%>

    <c:if test="${not empty sessionScope.cartMessage}">

        <div class="cart-message">
            ${sessionScope.cartMessage}
        </div>

        <c:remove var="cartMessage" scope="session"/>

    </c:if>


    <c:choose>

        <%-- Có sản phẩm trong giỏ --%>

        <c:when test="${not empty sessionScope.cart}">

            <div class="cart-container">

                <div class="cart-table-wrapper">

                    <table class="cart-table">

                        <thead>

                            <tr>
                                <th>Sản phẩm</th>
                                <th>Đơn giá</th>
                                <th>Số lượng</th>
                                <th>Thành tiền</th>
                                <th>Thao tác</th>
                            </tr>

                        </thead>


                        <tbody>

                            <c:set var="cartTotal" value="0"/>

                            <c:forEach
                                var="item"
                                items="${sessionScope.cart}">

                                <c:set
                                    var="cartTotal"
                                    value="${cartTotal + item.subtotal}"/>


                                <tr>

                                    <%-- SẢN PHẨM --%>

                                    <td>

                                        <div class="cart-product">

                                            <div class="product-image">

                                                <c:choose>

                                                    <c:when test="${not empty item.book.coverImage}">

                                                        <img
                                                            src="${pageContext.request.contextPath}/images/${item.book.coverImage}"
                                                            alt="${item.book.title}">

                                                    </c:when>

                                                    <c:otherwise>

                                                        <div class="no-image">
                                                            📚
                                                        </div>

                                                    </c:otherwise>

                                                </c:choose>

                                            </div>


                                            <div class="product-info">

                                                <a
                                                    href="${pageContext.request.contextPath}/book-detail?bookid=${item.book.bookid}"
                                                    class="product-title">

                                                    ${item.book.title}

                                                </a>

                                                <span class="book-id">
                                                    Mã sách: ${item.book.bookid}
                                                </span>

                                            </div>

                                        </div>

                                    </td>


                                    <%-- ĐƠN GIÁ --%>

                                    <td class="price">

                                        ${item.book.price} ₫

                                    </td>


                                    <%-- SỐ LƯỢNG --%>

                                    <td>

                                        <div class="quantity-area">

                                            <div class="quantity-control">

                                                <a
                                                    href="${pageContext.request.contextPath}/cart?action=decrease&bookid=${item.book.bookid}"
                                                    class="quantity-btn">
                                                    −
                                                </a>


                                                <span class="quantity-number">
                                                    ${item.quantity}
                                                </span>


                                                <a
                                                    href="${pageContext.request.contextPath}/cart?action=increase&bookid=${item.book.bookid}"
                                                    class="quantity-btn">
                                                    +
                                                </a>

                                            </div>


                                            <span class="stock-info">

                                                Còn ${item.book.quantity} sản phẩm

                                            </span>

                                        </div>

                                    </td>


                                    <%-- THÀNH TIỀN --%>

                                    <td class="subtotal">

                                        ${item.subtotal} ₫

                                    </td>


                                    <%-- XÓA --%>

                                    <td>

                                        <a
                                            href="${pageContext.request.contextPath}/cart?action=remove&bookid=${item.book.bookid}"
                                            class="remove-btn"
                                            onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này khỏi giỏ hàng?');">

                                            Xóa

                                        </a>

                                    </td>

                                </tr>

                            </c:forEach>

                        </tbody>

                    </table>

                </div>


                <%-- TỔNG TIỀN --%>

                <div class="cart-summary">

                    <div class="summary-row">

                        <span>
                            Tổng tiền:
                        </span>

                        <strong>
                            ${cartTotal} ₫
                        </strong>

                    </div>


                    <div class="summary-actions">

                        <a
                            href="${pageContext.request.contextPath}/home"
                            class="continue-btn">

                            ← Tiếp tục mua sắm

                        </a>


                        <a
                            href="${pageContext.request.contextPath}/checkout"
                            class="checkout-btn">

                            Tiến hành thanh toán →

                        </a>

                    </div>

                </div>

            </div>

        </c:when>


        <%-- GIỎ HÀNG TRỐNG --%>

        <c:otherwise>

            <div class="empty-cart">

                <div class="empty-cart-icon">
                    🛒
                </div>

                <h3>
                    Giỏ hàng đang trống
                </h3>

                <p>
                    Bạn chưa có sản phẩm nào trong giỏ hàng.
                </p>

                <a
                    href="${pageContext.request.contextPath}/home"
                    class="shopping-btn">

                    🛍️ Xem danh sách sách

                </a>

            </div>

        </c:otherwise>

    </c:choose>

</div>


<style>

/* =============================== */
/* CART PAGE */
/* =============================== */

.cart-page {
    max-width: 1200px;
    margin: 30px auto;
    padding: 0 20px 40px;
}


/* =============================== */
/* HEADER */
/* =============================== */

.cart-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 25px;
}

.cart-header h2 {
    margin: 0 0 8px;
    font-size: 28px;
}

.cart-header p {
    margin: 0;
    color: #666;
}


.back-btn {
    display: inline-block;
    padding: 10px 16px;
    border: 1px solid #ddd;
    border-radius: 6px;
    color: #333;
    background: #fff;
    text-decoration: none;
    white-space: nowrap;
}

.back-btn:hover {
    background: #f5f5f5;
}


/* =============================== */
/* MESSAGE */
/* =============================== */

.cart-message {
    padding: 12px 16px;
    margin-bottom: 20px;
    background: #fff3cd;
    color: #856404;
    border: 1px solid #ffeeba;
    border-radius: 6px;
}


/* =============================== */
/* CART TABLE */
/* =============================== */

.cart-container {
    background: #fff;
    border-radius: 10px;
}

.cart-table-wrapper {
    width: 100%;
    overflow-x: auto;
}


.cart-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 850px;
}


.cart-table th {
    padding: 15px;
    text-align: left;
    background: #f5f5f5;
    border-bottom: 1px solid #ddd;
    white-space: nowrap;
}


.cart-table td {
    padding: 18px 15px;
    border-bottom: 1px solid #eee;
    vertical-align: middle;
}


.cart-table tbody tr:hover {
    background: #fafafa;
}


/* =============================== */
/* PRODUCT */
/* =============================== */

.cart-product {
    display: flex;
    align-items: center;
    gap: 15px;
    min-width: 280px;
}


.product-image {
    width: 75px;
    height: 95px;
    flex-shrink: 0;
    border-radius: 6px;
    overflow: hidden;
    background: #f1f1f1;
}


.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}


.no-image {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 30px;
}


.product-info {
    display: flex;
    flex-direction: column;
    gap: 7px;
}


.product-title {
    color: #222;
    font-weight: bold;
    text-decoration: none;
}


.product-title:hover {
    text-decoration: underline;
}


.book-id {
    color: #777;
    font-size: 12px;
}


/* =============================== */
/* PRICE */
/* =============================== */

.price {
    white-space: nowrap;
}


/* =============================== */
/* QUANTITY */
/* =============================== */

.quantity-area {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
}


.quantity-control {
    display: flex;
    align-items: center;
    border: 1px solid #ddd;
    border-radius: 6px;
    overflow: hidden;
}


.quantity-btn {
    width: 34px;
    height: 34px;
    display: flex;
    justify-content: center;
    align-items: center;
    text-decoration: none;
    color: #333;
    background: #f5f5f5;
    font-size: 20px;
}


.quantity-btn:hover {
    background: #e8e8e8;
}


.quantity-number {
    min-width: 40px;
    text-align: center;
    font-weight: bold;
}


.stock-info {
    font-size: 12px;
    color: #777;
    white-space: nowrap;
}


/* =============================== */
/* SUBTOTAL */
/* =============================== */

.subtotal {
    font-weight: bold;
    white-space: nowrap;
}


/* =============================== */
/* REMOVE */
/* =============================== */

.remove-btn {
    color: #dc3545;
    text-decoration: none;
    font-size: 14px;
}


.remove-btn:hover {
    text-decoration: underline;
}


/* =============================== */
/* SUMMARY */
/* =============================== */

.cart-summary {
    padding: 25px;
    border-top: 1px solid #ddd;
}


.summary-row {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 30px;
    margin-bottom: 20px;
}


.summary-row span {
    font-size: 17px;
}


.summary-row strong {
    font-size: 24px;
}


.summary-actions {
    display: flex;
    justify-content: space-between;
    gap: 15px;
}


.continue-btn,
.checkout-btn {
    display: inline-block;
    padding: 12px 18px;
    border-radius: 6px;
    text-decoration: none;
}


.continue-btn {
    border: 1px solid #ddd;
    color: #333;
    background: #fff;
}


.continue-btn:hover {
    background: #f5f5f5;
}


.checkout-btn {
    background: #333;
    color: #fff;
}


.checkout-btn:hover {
    opacity: 0.85;
}


/* =============================== */
/* EMPTY CART */
/* =============================== */

.empty-cart {
    text-align: center;
    padding: 70px 20px;
    background: #fff;
    border-radius: 10px;
}


.empty-cart-icon {
    font-size: 65px;
    margin-bottom: 15px;
}


.empty-cart h3 {
    margin: 0 0 10px;
    font-size: 22px;
}


.empty-cart p {
    color: #666;
    margin-bottom: 25px;
}


.shopping-btn {
    display: inline-block;
    padding: 12px 20px;
    background: #333;
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
}


.shopping-btn:hover {
    opacity: 0.85;
}


/* =============================== */
/* RESPONSIVE */
/* =============================== */

@media (max-width: 700px) {

    .cart-header {
        flex-direction: column;
        align-items: flex-start;
    }

    .summary-actions {
        flex-direction: column;
    }

    .continue-btn,
    .checkout-btn {
        text-align: center;
    }

}

</style>