<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<div class="order-detail-page">

    <div class="page-header">
        <div>
            <h2>📦 Chi tiết đơn hàng #${order.orderId}</h2>
            <p>Thông tin chi tiết đơn hàng của bạn</p>
        </div>

        <a
            href="${pageContext.request.contextPath}/orders"
            class="back-btn">
            ← Quay lại đơn hàng
        </a>
    </div>


    <!-- ============================= -->
    <!-- THÔNG TIN ĐƠN HÀNG -->
    <!-- ============================= -->

    <div class="order-info-card">

        <div class="info-header">
            <h3>Thông tin đơn hàng</h3>

            <c:choose>

                <c:when test="${order.orderStatus == 'PENDING'}">
                    <span class="status pending">
                        Chờ xác nhận
                    </span>
                </c:when>

                <c:when test="${order.orderStatus == 'CONFIRMED'}">
                    <span class="status confirmed">
                        Đã xác nhận
                    </span>
                </c:when>

                <c:when test="${order.orderStatus == 'PREPARING'}">
                    <span class="status preparing">
                        Đang chuẩn bị
                    </span>
                </c:when>

                <c:when test="${order.orderStatus == 'SHIPPING'}">
                    <span class="status shipping">
                        Đang giao hàng
                    </span>
                </c:when>

                <c:when test="${order.orderStatus == 'DELIVERING'}">
                    <span class="status delivering">
                        Đang giao
                    </span>
                </c:when>

                <c:when test="${order.orderStatus == 'DELIVERED'}">
                    <span class="status delivered">
                        Đã giao
                    </span>
                </c:when>

                <c:when test="${order.orderStatus == 'CANCELLED'}">
                    <span class="status cancelled">
                        Đã hủy
                    </span>
                </c:when>

                <c:when test="${order.orderStatus == 'RETURNED'}">
                    <span class="status returned">
                        Đã trả hàng
                    </span>
                </c:when>

                <c:otherwise>
                    <span class="status">
                        ${order.orderStatus}
                    </span>
                </c:otherwise>

            </c:choose>

        </div>


        <div class="info-grid">

            <div class="info-item">
                <span class="label">
                    Mã đơn hàng
                </span>

                <strong>
                    #${order.orderId}
                </strong>
            </div>


            <div class="info-item">
                <span class="label">
                    Ngày đặt
                </span>

                <span>
                    ${order.createdAt}
                </span>
            </div>


            <div class="info-item">
                <span class="label">
                    Người nhận
                </span>

                <span>
                    ${order.receiverName}
                </span>
            </div>


            <div class="info-item">
                <span class="label">
                    Số điện thoại
                </span>

                <span>
                    ${order.receiverPhone}
                </span>
            </div>


            <div class="info-item full-width">
                <span class="label">
                    Địa chỉ nhận hàng
                </span>

                <span>
                    ${order.receiverAddress}
                </span>
            </div>


            <div class="info-item">
                <span class="label">
                    Phương thức thanh toán
                </span>

                <span>
                    <c:choose>

                        <c:when test="${order.paymentMethod == 'COD'}">
                            Thanh toán khi nhận hàng (COD)
                        </c:when>

                        <c:otherwise>
                            ${order.paymentMethod}
                        </c:otherwise>

                    </c:choose>
                </span>
            </div>

        </div>

    </div>


    <!-- ============================= -->
    <!-- DANH SÁCH SẢN PHẨM -->
    <!-- ============================= -->

    <div class="products-card">

        <h3>Sản phẩm đã đặt</h3>

        <c:choose>

            <c:when test="${not empty details}">

                <div class="products-table-wrapper">

                    <table class="products-table">

                        <thead>

                            <tr>
                                <th>Sản phẩm</th>
                                <th>Số lượng</th>
                                <th>Đơn giá</th>
                                <th>Thành tiền</th>
                            </tr>

                        </thead>


                        <tbody>

                            <c:forEach
                                var="detail"
                                items="${details}">

                                <tr>

                                    <td>

                                        <div class="product-name">

                                            <strong>
                                                ${detail.bookTitle}
                                            </strong>

                                            <span>
                                                Mã sách: ${detail.bookid}
                                            </span>

                                        </div>

                                    </td>


                                    <td>
                                        ${detail.quantity}
                                    </td>


                                    <td>
                                        ${detail.unitPrice} ₫
                                    </td>


                                    <td class="subtotal">
                                        ${detail.subtotal} ₫
                                    </td>

                                </tr>

                            </c:forEach>

                        </tbody>

                    </table>

                </div>

            </c:when>


            <c:otherwise>

                <div class="empty-detail">
                    Không có sản phẩm trong đơn hàng.
                </div>

            </c:otherwise>

        </c:choose>


        <!-- ============================= -->
        <!-- TỔNG TIỀN -->
        <!-- ============================= -->

        <div class="order-total-box">

            <span>
                Tổng tiền
            </span>

            <strong>
                ${order.totalAmount} ₫
            </strong>

        </div>

    </div>


    <!-- ============================= -->
    <!-- NÚT -->
    <!-- ============================= -->

    <div class="bottom-actions">

        <a
            href="${pageContext.request.contextPath}/orders"
            class="btn-secondary">
            ← Danh sách đơn hàng
        </a>

        <a
            href="${pageContext.request.contextPath}/home"
            class="btn-primary">
            🛒 Tiếp tục mua sắm
        </a>

    </div>

</div>


<style>

.order-detail-page {
    max-width: 1100px;
    margin: 30px auto;
    padding: 0 20px 40px;
}


/* ============================= */
/* HEADER */
/* ============================= */

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 25px;
}

.page-header h2 {
    margin: 0 0 7px;
    font-size: 28px;
}

.page-header p {
    margin: 0;
    color: #666;
}

.back-btn {
    text-decoration: none;
    color: #333;
    padding: 10px 15px;
    border: 1px solid #ddd;
    border-radius: 6px;
    white-space: nowrap;
}

.back-btn:hover {
    background: #f5f5f5;
}


/* ============================= */
/* CARD */
/* ============================= */

.order-info-card,
.products-card {
    background: #fff;
    border-radius: 10px;
    padding: 25px;
    margin-bottom: 20px;
    border: 1px solid #eee;
}


/* ============================= */
/* ORDER INFO */
/* ============================= */

.info-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    margin-bottom: 25px;
}

.info-header h3,
.products-card h3 {
    margin: 0;
    font-size: 20px;
}

.info-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.info-item {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.info-item.full-width {
    grid-column: 1 / -1;
}

.label {
    color: #777;
    font-size: 13px;
}


/* ============================= */
/* STATUS */
/* ============================= */

.status {
    display: inline-block;
    padding: 7px 12px;
    border-radius: 6px;
    font-size: 13px;
    white-space: nowrap;
}

.status.pending {
    background: #fff3cd;
    color: #856404;
}

.status.confirmed {
    background: #d1ecf1;
    color: #0c5460;
}

.status.preparing {
    background: #e2e3e5;
    color: #383d41;
}

.status.shipping,
.status.delivering {
    background: #cce5ff;
    color: #004085;
}

.status.delivered {
    background: #d4edda;
    color: #155724;
}

.status.cancelled {
    background: #f8d7da;
    color: #721c24;
}

.status.returned {
    background: #e2e3e5;
    color: #383d41;
}


/* ============================= */
/* PRODUCTS TABLE */
/* ============================= */

.products-card h3 {
    margin-bottom: 20px;
}

.products-table-wrapper {
    width: 100%;
    overflow-x: auto;
}

.products-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 650px;
}

.products-table th {
    background: #f5f5f5;
    padding: 14px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.products-table td {
    padding: 16px 14px;
    border-bottom: 1px solid #eee;
}

.products-table th:nth-child(2),
.products-table td:nth-child(2) {
    text-align: center;
}

.products-table th:nth-child(3),
.products-table td:nth-child(3),
.products-table th:nth-child(4),
.products-table td:nth-child(4) {
    text-align: right;
}

.product-name {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.product-name span {
    font-size: 12px;
    color: #777;
}

.subtotal {
    font-weight: bold;
}


/* ============================= */
/* TOTAL */
/* ============================= */

.order-total-box {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 30px;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #ddd;
}

.order-total-box span {
    font-size: 16px;
}

.order-total-box strong {
    font-size: 24px;
}


/* ============================= */
/* EMPTY */
/* ============================= */

.empty-detail {
    text-align: center;
    padding: 30px;
    color: #777;
}


/* ============================= */
/* BUTTONS */
/* ============================= */

.bottom-actions {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    margin-top: 20px;
}

.btn-primary,
.btn-secondary {
    display: inline-block;
    padding: 11px 18px;
    border-radius: 6px;
    text-decoration: none;
}

.btn-primary {
    background: #333;
    color: #fff;
}

.btn-secondary {
    border: 1px solid #ddd;
    color: #333;
    background: #fff;
}

.btn-primary:hover {
    opacity: 0.85;
}

.btn-secondary:hover {
    background: #f5f5f5;
}


/* ============================= */
/* RESPONSIVE */
/* ============================= */

@media (max-width: 700px) {

    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }

    .info-grid {
        grid-template-columns: 1fr;
    }

    .info-item.full-width {
        grid-column: auto;
    }

    .bottom-actions {
        flex-direction: column;
    }

    .btn-primary,
    .btn-secondary {
        text-align: center;
    }
}

</style>