<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Xác thực OTP</title>

    <style>
        .otp-container {
            width: 420px;
            margin: 60px auto;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
            text-align: center;
        }

        .otp-container h2 {
            margin-bottom: 15px;
            color: #1565c0;
        }

        .otp-container p {
            color: #666;
            margin-bottom: 20px;
        }

        .otp-input {
            width: 100%;
            padding: 12px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 20px;
            text-align: center;
            letter-spacing: 6px;
            margin-bottom: 15px;
        }

        .otp-button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 6px;
            background: #1565c0;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        .otp-button:hover {
            background: #0d47a1;
        }

        .error {
            color: #d32f2f;
            margin-bottom: 15px;
        }

        .success {
            color: #2e7d32;
            margin-bottom: 15px;
        }
    </style>
</head>

<body>

<div class="otp-container">

    <h2>Xác thực tài khoản</h2>

    <p>
        Mã OTP đã được gửi đến email của bạn.
        <br>
        Vui lòng nhập mã gồm 6 chữ số.
    </p>

    <% if (request.getAttribute("error") != null) { %>
        <div class="error">
            <%= request.getAttribute("error") %>
        </div>
    <% } %>

    <% if (request.getAttribute("message") != null) { %>
        <div class="success">
            <%= request.getAttribute("message") %>
        </div>
    <% } %>

    <form action="${pageContext.request.contextPath}/verify-otp"
          method="post">

        <input
            type="text"
            name="otp"
            class="otp-input"
            placeholder="000000"
            maxlength="6"
            pattern="[0-9]{6}"
            required
            autocomplete="off">

        <button type="submit" class="otp-button">
            Xác thực OTP
        </button>

    </form>

</div>

</body>
</html>