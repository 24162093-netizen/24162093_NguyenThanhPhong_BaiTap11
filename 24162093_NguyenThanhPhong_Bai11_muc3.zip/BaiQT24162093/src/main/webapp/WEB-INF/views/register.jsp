<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Đăng ký</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
        }

        .register-box {
            width: 450px;
            margin: 50px auto;
            padding: 30px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 12px;
            margin-bottom: 5px;
        }

        input {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background: #28a745;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background: #218838;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }

        .login {
            text-align: center;
            margin-top: 15px;
        }
    </style>
</head>

<body>

<div class="register-box">

    <h2>Đăng ký tài khoản</h2>

    <% if (request.getAttribute("error") != null) { %>
        <div class="error">
            ${error}
        </div>
    <% } %>

    <form action="${pageContext.request.contextPath}/register"
          method="post">

        <label>Email</label>
        <input type="email"
               name="email"
               required>

        <label>Họ và tên</label>
        <input type="text"
               name="fullname"
               required>

        <label>Số điện thoại</label>
        <input type="number"
               name="phone">

        <label>Mật khẩu</label>
        <input type="password"
               name="password"
               required>

        <button type="submit">
            Đăng ký
        </button>

    </form>

    <div class="login">
        Đã có tài khoản?
        <a href="${pageContext.request.contextPath}/login">
            Đăng nhập
        </a>
    </div>

</div>

</body>

</html>