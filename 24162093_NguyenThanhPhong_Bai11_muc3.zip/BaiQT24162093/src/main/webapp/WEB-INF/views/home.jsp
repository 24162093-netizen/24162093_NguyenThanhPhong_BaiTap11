<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>

<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Trang Chủ</title>

```
<style>
    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background: #f4f6f8;
        color: #333;
    }

    .container {
        width: 1100px;
        max-width: 95%;
        margin: 35px auto;
    }

    .page-title {
        text-align: center;
        margin-bottom: 30px;
    }

    .page-title h2 {
        margin: 0;
        color: #222;
        font-size: 28px;
    }

    .page-title p {
        margin-top: 8px;
        color: #777;
    }

    /* =========================
       DANH SÁCH SÁCH
       ========================= */

    .book-list {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 22px;
    }

    .book {
        background: #fff;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 3px 12px rgba(0, 0, 0, 0.08);
        transition: 0.25s;
    }

    .book:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    }

    .book-image {
        width: 100%;
        height: 280px;
        background: #eee;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }

    .book-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: 0.3s;
    }

    .book:hover .book-image img {
        transform: scale(1.04);
    }

    .no-image {
        color: #888;
        font-size: 15px;
    }

    .book-content {
        padding: 18px;
    }

    .book-title {
        min-height: 52px;
        margin: 0 0 14px;
    }

    .book-title a {
        color: #222;
        font-size: 19px;
        font-weight: bold;
        text-decoration: none;
        line-height: 1.4;
    }

    .book-title a:hover {
        color: #007bff;
    }

    .book-info {
        margin: 8px 0;
        font-size: 14px;
        color: #555;
    }

    .book-info strong {
        color: #333;
    }

    /* Tác giả */

    .author {
        margin: 8px 0 12px;
        padding: 8px 10px;
        background: #f0f7ff;
        border-left: 4px solid #007bff;
        border-radius: 5px;
        font-size: 14px;
        color: #333;
    }

    .author strong {
        color: #007bff;
    }

    .price {
        margin-top: 14px;
        font-size: 18px;
        font-weight: bold;
        color: #dc3545;
    }

    .quantity {
        display: inline-block;
        margin-top: 5px;
        padding: 5px 9px;
        border-radius: 5px;
        background: #eaf7ee;
        color: #198754;
        font-size: 13px;
    }

    .review-link {
        display: inline-block;
        margin-top: 12px;
        color: #007bff;
        font-size: 14px;
        text-decoration: none;
    }

    .review-link:hover {
        text-decoration: underline;
    }

    /* =========================
       EMPTY
       ========================= */

    .empty {
        padding: 50px;
        background: #fff;
        border-radius: 10px;
        text-align: center;
        color: #777;
        box-shadow: 0 3px 12px rgba(0, 0, 0, 0.06);
    }

    /* =========================
       PHÂN TRANG
       ========================= */

    .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 35px;
        gap: 5px;
    }

    .pagination a,
    .pagination span {
        min-width: 40px;
        padding: 9px 12px;
        border-radius: 6px;
        text-align: center;
        text-decoration: none;
        border: 1px solid #ddd;
    }

    .pagination a {
        background: #fff;
        color: #007bff;
    }

    .pagination a:hover {
        background: #007bff;
        color: #fff;
    }

    .pagination .current {
        background: #007bff;
        color: #fff;
        border-color: #007bff;
        font-weight: bold;
    }

    /* =========================
       RESPONSIVE
       ========================= */

    @media (max-width: 900px) {
        .book-list {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 600px) {
        .book-list {
            grid-template-columns: 1fr;
        }
    }
</style>
```

</head>

<body>

<div class="container">

```
<div class="page-title">
    <h2>Danh sách sách</h2>
    <p>Danh sách sách trong cửa hàng</p>
</div>

<c:choose>

    <c:when test="${not empty books}">

        <div class="book-list">

            <c:forEach var="book" items="${books}">

                <div class="book">

                    <!-- Ảnh sách -->
                    <div class="book-image">

                        <c:choose>

                            <c:when test="${not empty book.coverImage}">
                                <img
                                    src="${pageContext.request.contextPath}/images/${book.coverImage}"
                                    alt="${book.title}">
                            </c:when>

                            <c:otherwise>
                                <div class="no-image">
                                    Không có ảnh
                                </div>
                            </c:otherwise>

                        </c:choose>

                    </div>


                    <!-- Thông tin sách -->
                    <div class="book-content">

                        <h3 class="book-title">
                            <a href="${pageContext.request.contextPath}/book-detail?id=${book.bookid}">
                                ${book.title}
                            </a>
                        </h3>


                        <!-- Tác giả -->
                        <div class="author">
                            <strong>Tác giả:</strong>
                            ${book.authorName}
                        </div>


                        <p class="book-info">
                            <strong>Mã ISBN:</strong>
                            ${book.isbn}
                        </p>


                        <p class="book-info">
                            <strong>Nhà xuất bản:</strong>
                            ${book.publisher}
                        </p>


                        <p class="book-info">
                            <strong>Ngày xuất bản:</strong>
                            ${book.publishDate}
                        </p>


                        <p class="price">
                            ${book.price} VNĐ
                        </p>


                        <span class="quantity">
                            Số lượng: ${book.quantity}
                        </span>


                        <br>


                        <!-- Review -->
                        <a
                            class="review-link"
                            href="${pageContext.request.contextPath}/book-detail?id=${book.bookid}">
                            Review (10)
                        </a>

                    </div>

                </div>

            </c:forEach>

        </div>

    </c:when>


    <c:otherwise>

        <div class="empty">
            Chưa có sách trong hệ thống.
        </div>

    </c:otherwise>

</c:choose>


<!-- =========================
     PHÂN TRANG
     ========================= -->

<c:if test="${totalPages > 1}">

    <div class="pagination">

        <!-- Trước -->
        <c:if test="${currentPage > 1}">

            <a href="${pageContext.request.contextPath}/home?page=${currentPage - 1}">
                Trước
            </a>

        </c:if>


        <!-- Số trang -->
        <c:forEach
            begin="1"
            end="${totalPages}"
            var="page">

            <c:choose>

                <c:when test="${page == currentPage}">

                    <span class="current">
                        ${page}
                    </span>

                </c:when>

                <c:otherwise>

                    <a href="${pageContext.request.contextPath}/home?page=${page}">
                        ${page}
                    </a>

                </c:otherwise>

            </c:choose>

        </c:forEach>


        <!-- Sau -->
        <c:if test="${currentPage < totalPages}">

            <a href="${pageContext.request.contextPath}/home?page=${currentPage + 1}">
                Sau
            </a>

        </c:if>

    </div>

</c:if>
```

</div>

</body>
</html>
