<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<title>Đặt hàng thành công</title>

<style>
    .success-container {
        min-height: 500px;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 50px 20px;
    }

    .success-box {
        width: 600px;
        max-width: 95%;
        background: #ffffff;
        border-radius: 16px;
        padding: 45px 40px;
        text-align: center;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
    }

    .success-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 20px;
        border-radius: 50%;
        background: #e8f8ee;
        color: #28a745;
        font-size: 48px;
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .success-box h1 {
        color: #28a745;
        margin-bottom: 15px;
        font-size: 30px;
    }

    .success-message {
        color: #666;
        font-size: 17px;
        margin-bottom: 30px;
    }

    .order-info {
        background: #f7f9fc;
        border-radius: 10px;
        padding: 20px;
        text-align: left;
        margin-bottom: 30px;
    }

    .order-info p {
        margin: 10px 0;
        font-size: 16px;
        color: #444;
    }

    .order-info strong {
        color: #222;
    }

    .order-id {
        color: #007bff;
        font-weight: bold;
        font-size: 18px;
    }

    .status {
        color: #f39c12;
        font-weight: bold;
    }

    .success-buttons {
        display: flex;
        justify-content: center;
        gap: 15px;
        flex-wrap: wrap;
    }

    .btn-success {
        display: inline-block;
        padding: 12px 24px;
        border-radius: 8px;
        text-decoration: none;
        font-size: 16px;
        font-weight: bold;
        transition: 0.2s;
    }

    .btn-home {
        background: #007bff;
        color: white;
    }

    .btn-home:hover {
        background: #0056b3;
    }

    .btn-orders {
        background: #28a745;
        color: white;
    }

    .btn-orders:hover {
        background: #1e7e34;
    }
</style>

<div class="success-container">

    <div class="success-box">

        <div class="success-icon">
            ✓
        </div>

        <h1>Đặt hàng thành công!</h1>

        <p class="success-message">
            Cảm ơn bạn đã mua hàng. Đơn hàng của bạn đã được ghi nhận.
        </p>

        <div class="order-info">

            <p>
                <strong>Mã đơn hàng:</strong>
                <span class="order-id">
                    #${sessionScope.orderId}
                </span>
            </p>

            <p>
                <strong>Phương thức thanh toán:</strong>
                COD
            </p>

            <p>
                <strong>Trạng thái:</strong>
                <span class="status">Chờ xác nhận</span>
            </p>

        </div>

        <div class="success-buttons">

            <a href="${pageContext.request.contextPath}/home"
               class="btn-success btn-home">
                ← Về trang chủ
            </a>

            <a href="${pageContext.request.contextPath}/orders"
               class="btn-success btn-orders">
                Xem đơn hàng
            </a>

        </div>

    </div>

</div>