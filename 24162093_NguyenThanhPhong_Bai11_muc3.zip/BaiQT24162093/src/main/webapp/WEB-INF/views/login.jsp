<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
        }

        .login-box {
            width: 400px;
            margin: 80px auto;
            padding: 30px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 12px;
            margin-bottom: 5px;
        }

        input {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background: #0056b3;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }

        .register {
            text-align: center;
            margin-top: 15px;
        }
    </style>
</head>

<body>

<div class="login-box">

    <h2>Đăng nhập</h2>

    <% if (request.getAttribute("error") != null) { %>
        <div class="error">
            ${error}
        </div>
    <% } %>

    <form action="${pageContext.request.contextPath}/login"
          method="post">

        <label>Email</label>
        <input type="email"
               name="email"
               required>

        <label>Mật khẩu</label>
        <input type="password"
               name="password"
               required>

        <button type="submit">
            Đăng nhập
        </button>
    </form>

    <div class="register">
        Chưa có tài khoản?
        <a href="${pageContext.request.contextPath}/register">
            Đăng ký
        </a>
    </div>

</div>

</body>
</html>