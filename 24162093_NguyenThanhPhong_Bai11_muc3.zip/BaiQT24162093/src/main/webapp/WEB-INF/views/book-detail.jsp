<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">

<head>

    <meta charset="UTF-8">

    <title>${book.title}</title>

    <style>

        /* =========================
           THÔNG TIN SÁCH
           ========================= */

        .detail-container {
            width: 1100px;
            max-width: 95%;
            margin: 35px auto;
        }

        .book-detail {
            display: flex;
            gap: 35px;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }

        .cover {
            width: 320px;
            flex-shrink: 0;
        }

        .cover img {
            width: 100%;
            height: 430px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .no-image {
            width: 100%;
            height: 430px;
            background: #eee;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #888;
            border-radius: 8px;
        }

        .info {
            flex: 1;
        }

        .info h2 {
            margin-top: 0;
            margin-bottom: 20px;
            color: #222;
            font-size: 28px;
        }

        .info-row {
            margin: 13px 0;
            font-size: 15px;
            color: #555;
        }

        .info-row strong {
            color: #333;
            display: inline-block;
            min-width: 140px;
        }

        .author {
            margin: 15px 0;
            padding: 12px 15px;
            background: #f0f7ff;
            border-left: 4px solid #007bff;
            border-radius: 6px;
            color: #333;
        }

        .author strong {
            color: #007bff;
        }

        .price {
            margin: 20px 0;
            color: #dc3545;
            font-size: 23px;
            font-weight: bold;
        }

        .quantity {
            display: inline-block;
            padding: 7px 12px;
            background: #eaf7ee;
            color: #198754;
            border-radius: 6px;
            font-size: 14px;
        }

        /* =========================
           GIỎ HÀNG
           ========================= */

        .cart-form {
            margin-top: 20px;
        }

        .btn-cart {
            background: #198754;
            padding: 12px 24px;
            border-radius: 7px;
            font-size: 15px;
            font-weight: bold;
            color: white;
            border: none;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-cart:hover {
            background: #157347;
        }

        .btn-cart.disabled {
            background: #999;
            cursor: not-allowed;
        }

        .description {
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            line-height: 1.7;
            color: #555;
        }

        /* =========================
           REVIEWS
           ========================= */

        .reviews {
            margin-top: 30px;
            background: white;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }

        .reviews h2 {
            margin-top: 0;
            color: #222;
        }

        .review {
            padding: 18px 0;
            border-bottom: 1px solid #ddd;
        }

        .review:last-child {
            border-bottom: none;
        }

        .review-user {
            font-weight: bold;
            color: #007bff;
        }

        .review-rating {
            color: #dc3545;
            font-weight: bold;
        }

        .review-text {
            margin-top: 8px;
            color: #555;
            line-height: 1.6;
        }

        .no-review {
            color: #777;
        }

        /* =========================
           FORM REVIEW
           ========================= */

        .review-form {
            margin-top: 30px;
            background: white;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }

        .review-form h2 {
            margin-top: 0;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 7px;
            font-weight: bold;
        }

        select,
        textarea {
            width: 100%;
            padding: 11px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }

        textarea {
            min-height: 120px;
            resize: vertical;
        }

        select:focus,
        textarea:focus {
            outline: none;
            border-color: #007bff;
        }

        button {
            margin-top: 18px;
            padding: 11px 22px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: 0.2s;
        }

        button:hover {
            background: #0056b3;
        }

        .login-note {
            color: #666;
        }

        .login-note a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }

        .login-note a:hover {
            text-decoration: underline;
        }

        /* =========================
           RESPONSIVE
           ========================= */

        @media (max-width: 750px) {

            .book-detail {
                flex-direction: column;
            }

            .cover {
                width: 100%;
                max-width: 320px;
                margin: auto;
            }

        }

    </style>

</head>

<body>

<div class="detail-container">

    <!-- =========================
         THÔNG TIN SÁCH
         ========================= -->

    <div class="book-detail">

        <div class="cover">

            <c:choose>

                <c:when test="${not empty book.coverImage}">

                    <img
                        src="${pageContext.request.contextPath}/images/${book.coverImage}"
                        alt="${book.title}">

                </c:when>

                <c:otherwise>

                    <div class="no-image">
                        Không có ảnh
                    </div>

                </c:otherwise>

            </c:choose>

        </div>


        <div class="info">

            <h2>${book.title}</h2>

            <!-- Tác giả -->

            <div class="author">

                <strong>Tác giả:</strong>

                ${book.authorName}

            </div>


            <p class="info-row">

                <strong>ISBN:</strong>

                ${book.isbn}

            </p>


            <p class="info-row">

                <strong>Nhà xuất bản:</strong>

                ${book.publisher}

            </p>


            <p class="info-row">

                <strong>Ngày xuất bản:</strong>

                ${book.publishDate}

            </p>


            <p class="price">

                ${book.price} VNĐ

            </p>


            <span class="quantity">

                Số lượng: ${book.quantity}

            </span>


            <!-- =========================
                 THÊM VÀO GIỎ HÀNG
                 ========================= -->

            <c:choose>

                <c:when test="${book.quantity > 0}">

                    <form
                        action="${pageContext.request.contextPath}/cart"
                        method="get"
                        class="cart-form">

                        <input
                            type="hidden"
                            name="action"
                            value="add">

                        <input
                            type="hidden"
                            name="bookid"
                            value="${book.bookid}">

                        <button
                            type="submit"
                            class="btn-cart">

                            🛒 Thêm vào giỏ hàng

                        </button>

                    </form>

                </c:when>


                <c:otherwise>

                    <button
                        type="button"
                        class="btn-cart disabled"
                        disabled>

                        Hết hàng

                    </button>

                </c:otherwise>

            </c:choose>


            <div class="description">

                <strong>Mô tả:</strong>

                <p>

                    ${book.description}

                </p>

            </div>

        </div>

    </div>


    <!-- =========================
         REVIEWS
         ========================= -->

    <div class="reviews">

        <h2>Reviews (10)</h2>

        <c:choose>

            <c:when test="${not empty reviews}">

                <c:forEach var="review" items="${reviews}">

                    <div class="review">

                        <p>

                            <span class="review-user">

                                User ID: ${review.userid}

                            </span>

                        </p>


                        <p>

                            <span class="review-rating">

                                Đánh giá: ${review.rating}/5

                            </span>

                        </p>


                        <p class="review-text">

                            ${review.reviewText}

                        </p>

                    </div>

                </c:forEach>

            </c:when>


            <c:otherwise>

                <p class="no-review">

                    Chưa có đánh giá nào cho sách này.

                </p>

            </c:otherwise>

        </c:choose>

    </div>


    <!-- =========================
         FORM THÊM REVIEW
         ========================= -->

    <div class="review-form">

        <h2>Thêm đánh giá</h2>

        <c:choose>

            <c:when test="${not empty sessionScope.account}">

                <form
                    action="${pageContext.request.contextPath}/review"
                    method="post">

                    <input
                        type="hidden"
                        name="bookid"
                        value="${book.bookid}">


                    <label>Đánh giá</label>

                    <select name="rating" required>

                        <option value="5">
                            5 - Rất tốt
                        </option>

                        <option value="4">
                            4 - Tốt
                        </option>

                        <option value="3">
                            3 - Bình thường
                        </option>

                        <option value="2">
                            2 - Không tốt
                        </option>

                        <option value="1">
                            1 - Rất tệ
                        </option>

                    </select>


                    <label>Nội dung đánh giá</label>

                    <textarea
                        name="reviewText"
                        placeholder="Nhập nội dung đánh giá..."
                        required></textarea>


                    <button type="submit">

                        Gửi đánh giá

                    </button>

                </form>

            </c:when>


            <c:otherwise>

                <p class="login-note">

                    Vui lòng

                    <a href="${pageContext.request.contextPath}/login">

                        đăng nhập

                    </a>

                    để thêm đánh giá.

                </p>

            </c:otherwise>

        </c:choose>

    </div>

</div>

</body>

</html>