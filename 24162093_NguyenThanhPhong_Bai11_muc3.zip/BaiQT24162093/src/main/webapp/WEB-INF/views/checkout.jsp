<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Thanh toán</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            color: #333;
        }

        .checkout-container {
            width: 1100px;
            max-width: 95%;
            margin: 35px auto;
        }

        .checkout-title {
            margin-bottom: 25px;
            font-size: 28px;
            color: #222;
        }

        .checkout-content {
            display: flex;
            gap: 25px;
            align-items: flex-start;
        }

        .checkout-left {
            flex: 1;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.08);
        }

        .checkout-right {
            width: 380px;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.08);
        }

        h2 {
            margin-top: 0;
            margin-bottom: 20px;
            color: #222;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 11px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #007bff;
        }

        .payment-box {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 7px;
            background: #f8f9fa;
        }

        .payment-box label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .payment-box input {
            width: auto;
        }

        .cart-item {
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }

        .cart-item:last-child {
            border-bottom: none;
        }

        .item-title {
            font-weight: bold;
            margin-bottom: 7px;
        }

        .item-info {
            color: #666;
            font-size: 14px;
        }

        .item-subtotal {
            margin-top: 7px;
            color: #dc3545;
            font-weight: bold;
        }

        .total {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px solid #eee;

            display: flex;
            justify-content: space-between;

            font-size: 20px;
            font-weight: bold;
        }

        .total-price {
            color: #dc3545;
        }

        .btn-order {
            width: 100%;
            margin-top: 20px;
            padding: 13px;

            background: #007bff;
            color: white;

            border: none;
            border-radius: 7px;

            font-size: 16px;
            font-weight: bold;

            cursor: pointer;
        }

        .btn-order:hover {
            background: #0056b3;
        }

        .back-cart {
            display: inline-block;
            margin-top: 15px;

            color: #007bff;
            text-decoration: none;
        }

        .back-cart:hover {
            text-decoration: underline;
        }

        .empty-cart {
            text-align: center;
            padding: 40px;
            background: white;
            border-radius: 10px;
        }

        @media (max-width: 800px) {

            .checkout-content {
                flex-direction: column;
            }

            .checkout-right {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<div class="checkout-container">

    <h1 class="checkout-title">
        Thanh toán đơn hàng
    </h1>

    <c:choose>

        <c:when test="${not empty sessionScope.cart}">

            <div class="checkout-content">

                <!-- =========================
                     THÔNG TIN NHẬN HÀNG
                     ========================= -->

                <div class="checkout-left">

                    <h2>
                        Thông tin nhận hàng
                    </h2>

                    <form
                        action="${pageContext.request.contextPath}/checkout"
                        method="post">

                        <div class="form-group">

                            <label>
                                Họ và tên người nhận
                            </label>

                            <input
                                type="text"
                                name="receiverName"
                                value="${sessionScope.account.fullname}"
                                required>

                        </div>


                        <div class="form-group">

                            <label>
                                Số điện thoại
                            </label>

                            <input
                                type="text"
                                name="receiverPhone"
                                value="${sessionScope.account.phone}"
                                required>

                        </div>


                        <div class="form-group">

                            <label>
                                Địa chỉ nhận hàng
                            </label>

                            <textarea
                                name="receiverAddress"
                                placeholder="Nhập địa chỉ nhận hàng..."
                                required></textarea>

                        </div>


                        <div class="form-group">

                            <label>
                                Phương thức thanh toán
                            </label>

                            <div class="payment-box">

                                <label>

                                    <input
                                        type="radio"
                                        name="paymentMethod"
                                        value="COD"
                                        checked>

                                    Thanh toán khi nhận hàng (COD)

                                </label>

                            </div>

                        </div>


                        <button
                            type="submit"
                            class="btn-order">

                            Đặt hàng

                        </button>

                    </form>


                    <a
                        href="${pageContext.request.contextPath}/cart"
                        class="back-cart">

                        ← Quay lại giỏ hàng

                    </a>

                </div>


                <!-- =========================
                     TÓM TẮT ĐƠN HÀNG
                     ========================= -->

                <div class="checkout-right">

                    <h2>
                        Đơn hàng
                    </h2>


                    <c:set
                        var="total"
                        value="0" />


                    <c:forEach
                        var="item"
                        items="${sessionScope.cart}">

                        <div class="cart-item">

                            <div class="item-title">
                                ${item.book.title}
                            </div>

                            <div class="item-info">

                                Số lượng:
                                ${item.quantity}

                            </div>

                            <div class="item-info">

                                Đơn giá:
                                ${item.book.price} VNĐ

                            </div>

                            <div class="item-subtotal">

                                ${item.subtotal} VNĐ

                            </div>

                        </div>


                        <c:set
                            var="total"
                            value="${total + item.subtotal}" />

                    </c:forEach>


                    <div class="total">

                        <span>
                            Tổng cộng:
                        </span>

                        <span class="total-price">

                            ${total} VNĐ

                        </span>

                    </div>

                </div>

            </div>

        </c:when>


        <c:otherwise>

            <div class="empty-cart">

                <h2>
                    Giỏ hàng đang trống
                </h2>

                <p>
                    Bạn chưa có sản phẩm nào để thanh toán.
                </p>

                <a
                    href="${pageContext.request.contextPath}/home"
                    class="back-cart">

                    ← Tiếp tục mua sách

                </a>

            </div>

        </c:otherwise>

    </c:choose>

</div>

</body>

</html>