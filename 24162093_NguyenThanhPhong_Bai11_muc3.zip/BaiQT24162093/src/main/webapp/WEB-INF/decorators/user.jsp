<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<!DOCTYPE html>
<html lang="vi">

<head>

<meta charset="UTF-8">

<title><sitemesh:write property="title" /></title>

<sitemesh:write property="head" />

<style>
* {
	box-sizing: border-box;
}

body {
	margin: 0;
	font-family: Arial, sans-serif;
	background: #f4f6f8;
	color: #333;
}

/* =========================
           HEADER
           ========================= */
.site-header {
	background: linear-gradient(135deg, #007bff, #0056b3);
	color: white;
	box-shadow: 0 3px 12px rgba(0, 0, 0, 0.18);
}

.header-container {
	width: 1100px;
	max-width: 95%;
	margin: auto;
	min-height: 90px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 25px;
}

.logo {
	font-size: 25px;
	font-weight: bold;
	white-space: nowrap;
}

.logo span {
	display: block;
	font-size: 13px;
	font-weight: normal;
	margin-top: 4px;
	opacity: 0.85;
}

/* =========================
           NAVIGATION
           ========================= */
.main-nav {
	display: flex;
	align-items: center;
	gap: 6px;
	flex-wrap: wrap;
	justify-content: flex-end;
}

.main-nav a {
	color: white;
	text-decoration: none;
	padding: 10px 14px;
	border-radius: 7px;
	font-size: 15px;
	transition: 0.25s;
}

.main-nav a:hover {
	background: rgba(255, 255, 255, 0.18);
	transform: translateY(-1px);
}

.nav-separator {
	color: rgba(255, 255, 255, 0.45);
}

/* =========================
           CHÀO NGƯỜI DÙNG
           ========================= */
.welcome-user {
	color: white;
	font-size: 14px;
	padding: 8px 10px;
	white-space: nowrap;
}

.welcome-user strong {
	font-weight: bold;
}

/* =========================
           GIỎ HÀNG
           ========================= */
.cart-link {
	position: relative;
	background: rgba(255, 255, 255, 0.16);
	border: 1px solid rgba(255, 255, 255, 0.3);
}

.cart-link:hover {
	background: rgba(255, 255, 255, 0.25) !important;
}

.cart-count {
	display: inline-flex;
	min-width: 20px;
	height: 20px;
	padding: 0 5px;
	align-items: center;
	justify-content: center;
	margin-left: 4px;
	background: #dc3545;
	color: white;
	border-radius: 50%;
	font-size: 12px;
	font-weight: bold;
}

/* =========================
           ADMIN LINK
           ========================= */
.admin-link {
	background: rgba(255, 255, 255, 0.16);
	border: 1px solid rgba(255, 255, 255, 0.3);
}

/* =========================
           MAIN
           ========================= */
main {
	min-height: calc(100vh - 165px);
}

/* =========================
           FOOTER
           ========================= */
.site-footer {
	margin-top: 45px;
	background: #212529;
	color: #ddd;
	text-align: center;
	padding: 22px 15px;
	box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.08);
}

.site-footer p {
	margin: 0;
	font-size: 14px;
}

.footer-title {
	color: white;
	font-weight: bold;
	margin-bottom: 7px;
	font-size: 15px;
}

/* =========================
           RESPONSIVE
           ========================= */
@media ( max-width : 900px) {
	.header-container {
		flex-direction: column;
		justify-content: center;
		padding: 18px 0;
	}
	.logo {
		text-align: center;
	}
	.main-nav {
		justify-content: center;
	}
}
</style>

</head>

<body>

	<!-- =========================
         HEADER
         ========================= -->

	<header class="site-header">

		<div class="header-container">

			<div class="logo">

				Trang Web Bán Sách <span> Hệ thống quản lý và bán sách </span>

			</div>


			<nav class="main-nav">

				<a href="${pageContext.request.contextPath}/home"> Trang Chủ </a> <span
					class="nav-separator">|</span> <a
					href="${pageContext.request.contextPath}/home"> Sản phẩm </a>


				<c:choose>

					<c:when test="${not empty sessionScope.account}">

						<span class="nav-separator">|</span>

						<!-- CHÀO NGƯỜI DÙNG -->

						<span class="welcome-user"> Xin chào, <strong>
								${sessionScope.account.fullname} </strong>

						</span>


						<span class="nav-separator">|</span>


						<!-- GIỎ HÀNG -->

						<a href="${pageContext.request.contextPath}/cart"
							class="cart-link"> 🛒 Giỏ hàng <c:set var="cartCount"
								value="0" /> <c:forEach var="item" items="${sessionScope.cart}">

								<c:set var="cartCount" value="${cartCount + item.quantity}" />

							</c:forEach> <span class="cart-count"> ${cartCount} </span>

						</a>

						<a href="${pageContext.request.contextPath}/orders"
							class="orders-link"> 📦 Đơn hàng </a>


						<span class="nav-separator">|</span>


						<!-- ĐĂNG XUẤT -->

						<a href="${pageContext.request.contextPath}/logout"> Đăng xuất

						</a>


						<!-- ADMIN -->

						<c:if test="${sessionScope.account.admin}">

							<span class="nav-separator">|</span>

							<a class="admin-link"
								href="${pageContext.request.contextPath}/admin/books"> Trang
								quản trị </a>

						</c:if>

					</c:when>


					<c:otherwise>

						<span class="nav-separator">|</span>

						<a href="${pageContext.request.contextPath}/login"> Đăng nhập

						</a>

					</c:otherwise>

				</c:choose>

			</nav>

		</div>

	</header>


	<!-- =========================
         CONTENT
         ========================= -->

	<main>

		<sitemesh:write property="body" />

	</main>


	<!-- =========================
         FOOTER
         ========================= -->

	<footer class="site-footer">

		<div class="footer-title">Trang Web Bán Sách</div>

		<p>Họ tên: Nguyễn Thanh Phong &nbsp; | &nbsp; MSSV: 24162093

			&nbsp; | &nbsp; Mã đề: 02</p>

	</footer>

</body>

</html>