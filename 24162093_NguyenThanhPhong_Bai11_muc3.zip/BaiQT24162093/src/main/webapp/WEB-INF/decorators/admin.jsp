<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">
<head>

    <meta charset="UTF-8">

    <title>
        <sitemesh:write property="title" />
    </title>

    <sitemesh:write property="head" />

    <style>
        * {
            box-sizing: border-box;
        }

        html {
            min-height: 100%;
        }

        body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            color: #333;
        }

        /* =========================
           ADMIN HEADER
           ========================= */

        .admin-header {
            width: 100%;
            background: linear-gradient(135deg, #212529, #343a40);
            color: white;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.2);
        }

        .admin-header-container {
            width: 1100px;
            max-width: 95%;
            min-height: 85px;
            margin: 0 auto;

            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 30px;
        }

        .admin-logo {
            font-size: 24px;
            font-weight: bold;
            white-space: nowrap;
        }

        .admin-logo span {
            display: block;
            font-size: 13px;
            font-weight: normal;
            color: #adb5bd;
            margin-top: 5px;
        }

        /* =========================
           NAVIGATION
           ========================= */

        .admin-nav {
            display: flex;
            align-items: center;
            gap: 7px;
            flex-wrap: wrap;
        }

        .admin-nav a {
            color: #e9ecef;
            text-decoration: none;

            padding: 10px 14px;

            border-radius: 7px;

            font-size: 14px;

            transition: background-color 0.2s ease,
                        color 0.2s ease;
        }

        .admin-nav a:hover {
            background: #495057;
            color: white;
        }

        .admin-nav .active {
            background: #007bff;
            color: white;
        }

        .logout {
            border: 1px solid #6c757d;
        }

        .logout:hover {
            background: #dc3545 !important;
            border-color: #dc3545 !important;
        }

        /* =========================
           MAIN
           ========================= */

        .admin-main {
            width: 1100px;
            max-width: 95%;

            min-height: calc(100vh - 165px);

            margin: 30px auto;

            /* Giữ kích thước ổn định */
            overflow: hidden;
        }

        /* =========================
           FOOTER
           ========================= */

        .admin-footer {
            width: 100%;

            margin-top: 40px;

            padding: 22px 15px;

            background: #212529;

            color: #adb5bd;

            text-align: center;

            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.08);
        }

        .admin-footer-title {
            color: white;

            font-weight: bold;

            margin-bottom: 7px;
        }

        .admin-footer p {
            margin: 0;

            font-size: 14px;
        }

        /* =========================
           RESPONSIVE
           ========================= */

        @media (max-width: 750px) {

            .admin-header-container {
                flex-direction: column;

                justify-content: center;

                padding: 18px 0;
            }

            .admin-logo {
                text-align: center;
            }

            .admin-nav {
                justify-content: center;
            }

            .admin-main {
                max-width: 94%;

                margin: 20px auto;

                overflow-x: auto;
            }
        }
    </style>

</head>

<body>

    <!-- =========================
         ADMIN HEADER
         ========================= -->

    <header class="admin-header">

        <div class="admin-header-container">

            <div class="admin-logo">

                Trang Quản Trị

                <span>
                    Hệ thống quản lý sách
                </span>

            </div>

            <nav class="admin-nav">

                <a href="${pageContext.request.contextPath}/home">
                    Trang Chủ
                </a>

                <a href="${pageContext.request.contextPath}/home">
                    Sản phẩm
                </a>

                <a href="${pageContext.request.contextPath}/admin/books">
                    Quản lý sách
                </a>

                <a class="logout"
                   href="${pageContext.request.contextPath}/logout">
                    Đăng xuất
                </a>

            </nav>

        </div>

    </header>


    <!-- =========================
         ADMIN CONTENT
         ========================= -->

    <main class="admin-main">

        <sitemesh:write property="body" />

    </main>


    <!-- =========================
         ADMIN FOOTER
         ========================= -->

    <footer class="admin-footer">

        <div class="admin-footer-title">
            Trang Quản Trị - Website Bán Sách
        </div>

        <p>
            Họ tên: Nguyễn Thanh Phong
            &nbsp; | &nbsp;
            MSSV: 24162093
            &nbsp; | &nbsp;
            Mã đề: 02
        </p>

    </footer>

</body>

</html>